# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------
from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from subprocess import PIPE, Popen
from typing import TYPE_CHECKING, Any

from azure.cli.core import get_default_cli, telemetry
from azure.cli.core.azclierror import (
    ArgumentUsageError,
    AzureInternalError,
    AzureResponseError,
    ClientRequestError,
    CLIInternalError,
    ManualInterrupt,
    ValidationError,
)
from azure.cli.core.commands.client_factory import get_subscription_id
from azure.cli.core.util import send_raw_request
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from knack.log import get_logger
from knack.prompting import NoTTYException, prompt_y_n
from kubernetes import client as kube_client
from kubernetes.client.rest import ApiException
from msrest.exceptions import AuthenticationError, HttpOperationError, TokenExpiredError
from msrest.exceptions import ValidationError as MSRestValidationError
from packaging import version

import azext_connectedk8s._constants as consts
import azext_connectedk8s._errors as errors
from azext_connectedk8s._client_factory import (
    cf_resource_groups,
    resource_providers_client,
)

if TYPE_CHECKING:
    from azure.cli.core import AzCli
    from azure.cli.core.azclierror import AzCLIError
    from knack.commands import CLICommand
    from kubernetes.client import CoreV1Api, V1NodeList
    from requests import Response

    from azext_connectedk8s.vendored_sdks.preview_2025_08_01.models import (
        ConnectedCluster,
    )

logger = get_logger(__name__)

# pylint: disable=line-too-long
# pylint: disable=bare-except
# pylint: disable=consider-using-with
# pylint: disable=too-many-positional-arguments
# pylint: disable=too-many-statements
# pylint: disable=too-many-lines
# Long diagnostic and command strings are kept readable in one place for operator troubleshooting.
# Some broad exception boundaries are retained to keep best-effort cleanup and telemetry collection.

HELM_TIMEOUT_USER_FAULT_CLASSIFICATIONS = {
    "ImagePullFailure",
    "PendingOrUnschedulable",
}


@dataclass(frozen=True)
class HelmTimeoutReport:
    """Standardized error context collected after a Helm timeout."""

    error: errors.ArcError
    details: str
    telemetry_properties: dict[str, str]
    user_fault: bool


def is_helm_timeout_error(error_message: str) -> bool:
    error_message_lower = error_message.lower()
    return any(
        message in error_message_lower for message in consts.Helm_Timeout_Messages
    )


def _truncate_timeout_diagnostic_message(message: str, limit: int = 240) -> str:
    message = " ".join(message.split())
    if len(message) <= limit:
        return message
    return message[: limit - 3] + "..."


def _get_object_value(obj: Any, *attrs: str) -> Any:
    value = obj
    for attr in attrs:
        if value is None:
            return None
        value = getattr(value, attr, None)
    return value


def _get_event_timestamp(event: Any) -> str:
    timestamp = (
        _get_object_value(event, "last_timestamp")
        or _get_object_value(event, "event_time")
        or _get_object_value(event, "metadata", "creation_timestamp")
    )
    return str(timestamp or "")


def _collect_timeout_diagnostics_from_pods(
    pods: list[Any],
) -> tuple[list[str], set[str]]:
    evidence: list[str] = []
    classifications: set[str] = set()

    for pod in pods:
        pod_name = _get_object_value(pod, "metadata", "name") or "<unknown>"
        pod_phase = _get_object_value(pod, "status", "phase")
        container_statuses = (
            _get_object_value(pod, "status", "init_container_statuses") or []
        ) + (_get_object_value(pod, "status", "container_statuses") or [])

        if pod_phase == "Pending" and not container_statuses:
            classifications.add("PendingOrUnschedulable")
            evidence.append(
                f"Pod {pod_name} is Pending and has no container status yet."
            )

        for container_status in container_statuses:
            waiting_state = _get_object_value(container_status, "state", "waiting")
            if waiting_state is None:
                continue

            reason = _get_object_value(waiting_state, "reason")
            if not reason:
                continue

            container_name = _get_object_value(container_status, "name") or "<unknown>"
            restart_count = _get_object_value(container_status, "restart_count")
            message = _get_object_value(waiting_state, "message")
            if reason in ("ImagePullBackOff", "ErrImagePull"):
                classifications.add("ImagePullFailure")
            elif reason == "CrashLoopBackOff":
                classifications.add("CrashLoopBackOff")
            elif reason in ("CreateContainerConfigError", "CreateContainerError"):
                classifications.add("ContainerCreateFailure")

            detail = f"Pod {pod_name} container {container_name} is waiting: {reason}"
            if restart_count is not None:
                detail += f", restarts={restart_count}"
            if message:
                detail += (
                    f", message={_truncate_timeout_diagnostic_message(str(message))}"
                )
            evidence.append(detail)

    return evidence, classifications


def _collect_timeout_diagnostics_from_events(
    events: list[Any],
) -> tuple[list[str], set[str]]:
    evidence: list[str] = []
    classifications: set[str] = set()
    warning_events = [
        event for event in events if _get_object_value(event, "type") == "Warning"
    ]
    warning_events.sort(key=_get_event_timestamp, reverse=True)

    for event in warning_events[: consts.Max_Helm_Timeout_Event_Evidence]:
        reason = _get_object_value(event, "reason") or "<unknown>"
        message = _get_object_value(event, "message") or ""
        involved_name = (
            _get_object_value(event, "involved_object", "name") or "<unknown>"
        )
        message_lower = str(message).lower()

        if reason in ("FailedScheduling", "NotTriggerScaleUp") or any(
            signal in message_lower
            for signal in (
                "insufficient",
                "taint",
                "didn't match",
                "node affinity",
                "node selector",
                "max node group size reached",
            )
        ):
            classifications.add("ClusterResourceOrSchedulingConstraint")
        if reason in ("Failed", "BackOff", "FailedPull", "ErrImagePull") and any(
            signal in message_lower
            for signal in ("pull", "image", "registry", "unauthorized", "not found")
        ):
            classifications.add("ImagePullFailure")
        if (
            reason == "FailedMount"
            and "secret" in message_lower
            and "not found" in message_lower
        ):
            classifications.add("KeyPairOrIdentityCertificateSync")
            if consts.MSI_Certificate_Secret_Name in message:
                classifications.add("MissingIdentityCertificateSecret")
            if consts.KAP_Certificate_Secret_Name in message:
                classifications.add("MissingKubeAadProxyCertificateSecret")

        evidence.append(
            "Warning event for "
            f"{involved_name}: {reason} - {_truncate_timeout_diagnostic_message(str(message))}"
        )

    return evidence, classifications


def _collect_clusteridentityoperator_evidence(
    pods: list[Any], secret_names: set[str] | None
) -> tuple[list[str], set[str]]:
    evidence: list[str] = []
    classifications: set[str] = set()
    cluster_identity_pods = [
        pod
        for pod in pods
        if str(_get_object_value(pod, "metadata", "name") or "").startswith(
            consts.Cluster_Identity_Operator_Prefix
        )
    ]

    if (
        secret_names is not None
        and consts.MSI_Certificate_Secret_Name not in secret_names
    ):
        classifications.add("MissingIdentityCertificateSecret")
        classifications.add("KeyPairOrIdentityCertificateSync")
        evidence.append(
            f"Secret {consts.MSI_Certificate_Secret_Name} is not present in namespace {consts.Arc_Namespace}."
        )
        if not cluster_identity_pods:
            evidence.append(
                f"No clusteridentityoperator pod was found in namespace {consts.Arc_Namespace}."
            )

    for pod in cluster_identity_pods:
        pod_name = _get_object_value(pod, "metadata", "name")
        container_statuses = (
            _get_object_value(pod, "status", "container_statuses") or []
        )
        for container_status in container_statuses:
            waiting_reason = _get_object_value(
                container_status, "state", "waiting", "reason"
            )
            if waiting_reason:
                evidence.append(
                    f"clusteridentityoperator pod {pod_name} container "
                    f"{_get_object_value(container_status, 'name') or '<unknown>'} is waiting: {waiting_reason}."
                )

    if (
        secret_names is not None
        and consts.MSI_Certificate_Secret_Name not in secret_names
        and cluster_identity_pods
        and any("clusteridentityoperator" in item for item in evidence)
    ):
        classifications.add("KeyPairOrIdentityCertificateSync")

    return evidence, classifications


def _list_secret_names_metadata_only(corev1_api_instance: CoreV1Api) -> set[str]:
    secrets_metadata = corev1_api_instance.api_client.call_api(
        f"/api/v1/namespaces/{consts.Arc_Namespace}/secrets",
        "GET",
        auth_settings=["BearerToken"],
        header_params={
            "Accept": "application/json;as=PartialObjectMetadataList;g=meta.k8s.io;v=v1"
        },
        response_type="object",
        _return_http_data_only=True,
    )
    return {
        item["metadata"]["name"]
        for item in secrets_metadata.get("items", [])
        if item.get("metadata", {}).get("name")
    }


def _resolve_helm_timeout_classification(classifications: set[str]) -> str:
    if "ImagePullFailure" in classifications:
        return "ImagePullFailure"
    if any(
        classification in classifications
        for classification in (
            "PendingOrUnschedulable",
            "ClusterResourceOrSchedulingConstraint",
        )
    ):
        return "PendingOrUnschedulable"
    if any(
        classification in classifications
        for classification in (
            "KeyPairOrIdentityCertificateSync",
            "MissingIdentityCertificateSecret",
            "MissingKubeAadProxyCertificateSecret",
        )
    ):
        return "ClusterIdentityFailure"
    return "GenericHelmTimeout"


def _build_helm_timeout_telemetry_properties(
    classification_signals: set[str],
    evidence_count: int,
    diagnostics_status: str,
    helm_operation: str | None,
) -> dict[str, str]:
    resolved_classification = _resolve_helm_timeout_classification(
        classification_signals
    )
    properties = {
        "Context.Default.AzureCLI.helmTimeout": "true",
        "Context.Default.AzureCLI.helmTimeoutDiagnosticsStatus": diagnostics_status,
        "Context.Default.AzureCLI.helmTimeoutClassification": resolved_classification,
        "Context.Default.AzureCLI.helmTimeoutEvidenceCount": str(evidence_count),
    }
    if helm_operation:
        properties["Context.Default.AzureCLI.helmOperation"] = helm_operation

    for classification in consts.Helm_Timeout_Resolved_Classifications:
        properties[f"Context.Default.AzureCLI.helmTimeout{classification}"] = str(
            classification == resolved_classification
        ).lower()

    return properties


def _get_helm_timeout_classification_from_properties(
    telemetry_properties: dict[str, str],
) -> str:
    return telemetry_properties.get(
        "Context.Default.AzureCLI.helmTimeoutClassification", ""
    )


def _build_helm_timeout_user_message(classification: str) -> str:
    return errors.get_helm_timeout_error(classification).format()


def is_advanced_helm_timeout_diagnostics(error_message: str) -> bool:
    return "Read-only cluster checks after Helm timeout:" in error_message


def get_advanced_helm_timeout_fault_type(error_message: str) -> str | None:
    if not is_advanced_helm_timeout_diagnostics(error_message):
        return None

    for error in errors.HELM_TIMEOUT_ERRORS.values():
        if f"[{error.code}]" in error_message:
            return error.fault_type

    return consts.Helm_Timeout_Generic_Fault_Type


def _collect_arc_agent_timeout_diagnostics() -> tuple[str, dict[str, str]]:
    try:
        corev1_api_instance = kube_client.CoreV1Api()
        evidence: list[str] = []
        classifications: set[str] = set()
        diagnostics_status = "Collected"

        try:
            pods = corev1_api_instance.list_namespaced_pod(consts.Arc_Namespace).items
        except Exception as e:  # pylint: disable=broad-except
            logger.debug(
                "Unable to list %s pods after Helm timeout.",
                consts.Arc_Namespace,
                exc_info=True,
            )
            diagnostics_status = "Failed"
            return (
                f"Unable to list pods in namespace {consts.Arc_Namespace}: {e}",
                _build_helm_timeout_telemetry_properties(
                    classifications, 0, diagnostics_status, None
                ),
            )

        try:
            events = corev1_api_instance.list_namespaced_event(
                consts.Arc_Namespace
            ).items
        except Exception as e:  # pylint: disable=broad-except
            logger.debug(
                "Unable to list %s events after Helm timeout.",
                consts.Arc_Namespace,
                exc_info=True,
            )
            diagnostics_status = "Partial"
            evidence.append(
                f"Unable to list events in namespace {consts.Arc_Namespace}: "
                + _truncate_timeout_diagnostic_message(str(e))
            )
            events = []

        try:
            secret_names: set[str] | None = _list_secret_names_metadata_only(
                corev1_api_instance
            )
        except Exception as e:  # pylint: disable=broad-except
            logger.debug(
                "Unable to list %s secrets after Helm timeout.",
                consts.Arc_Namespace,
                exc_info=True,
            )
            diagnostics_status = "Partial"
            evidence.append(
                f"Unable to list secret metadata in namespace {consts.Arc_Namespace}: "
                + _truncate_timeout_diagnostic_message(str(e))
            )
            secret_names = None

        pod_evidence, pod_classifications = _collect_timeout_diagnostics_from_pods(pods)
        event_evidence, event_classifications = (
            _collect_timeout_diagnostics_from_events(events)
        )
        (
            identity_evidence,
            identity_classifications,
        ) = _collect_clusteridentityoperator_evidence(pods, secret_names)

        evidence.extend(pod_evidence)
        evidence.extend(event_evidence)
        evidence.extend(identity_evidence)
        classifications.update(pod_classifications)
        classifications.update(event_classifications)
        classifications.update(identity_classifications)

        resolved_classification = _resolve_helm_timeout_classification(classifications)
        if evidence:
            evidence_summary = "\n".join(
                evidence[: consts.Max_Helm_Timeout_Diagnostic_Evidence]
            )
            omitted_count = len(evidence) - consts.Max_Helm_Timeout_Diagnostic_Evidence
            if omitted_count > 0:
                evidence_summary += (
                    f"\n... {omitted_count} additional signal(s) omitted."
                )
            logger.debug(
                "Read-only cluster checks after Helm timeout classified as %s. Evidence:\n%s",
                resolved_classification,
                evidence_summary,
            )
        else:
            logger.debug(
                "Read-only cluster checks after Helm timeout classified as %s. "
                "No pod wait reasons, warning events, or missing identity certificate "
                f"signals were found in namespace {consts.Arc_Namespace}.",
                resolved_classification,
            )

        result = _build_helm_timeout_user_message(resolved_classification)
        return (
            result,
            _build_helm_timeout_telemetry_properties(
                classifications, len(evidence), diagnostics_status, None
            ),
        )
    except Exception as e:  # pylint: disable=broad-except
        logger.debug("Unable to collect post-Helm-timeout diagnostics.", exc_info=True)
        return (
            f"Unable to collect post-Helm-timeout diagnostics: {e}",
            _build_helm_timeout_telemetry_properties(set(), 0, "Failed", None),
        )


def collect_arc_agent_timeout_diagnostics() -> str:
    diagnostics, _ = _collect_arc_agent_timeout_diagnostics()
    return diagnostics


def build_helm_timeout_report(
    error_message: str,
    helm_operation: str | None = None,
) -> HelmTimeoutReport | None:
    if not is_helm_timeout_error(error_message):
        return None

    diagnostics, telemetry_properties = _collect_arc_agent_timeout_diagnostics()
    if helm_operation:
        telemetry_properties["Context.Default.AzureCLI.helmOperation"] = helm_operation
    classification = _get_helm_timeout_classification_from_properties(
        telemetry_properties
    )
    details = f"Helm command output:\n{error_message}"
    if (
        telemetry_properties["Context.Default.AzureCLI.helmTimeoutDiagnosticsStatus"]
        == "Failed"
    ):
        details += f"\n\nPost-timeout diagnostics:\n{diagnostics}"
    return HelmTimeoutReport(
        error=errors.get_helm_timeout_error(classification),
        details=details,
        telemetry_properties=telemetry_properties,
        user_fault=classification in HELM_TIMEOUT_USER_FAULT_CLASSIFICATIONS,
    )


def build_connected_cluster_arm_id(
    subscription_id: str, resource_group_name: str, cluster_name: str
) -> str:
    return (
        f"/subscriptions/{subscription_id}"
        f"/resourceGroups/{resource_group_name}"
        f"/providers/Microsoft.Kubernetes/connectedClusters/{cluster_name}"
    )


def set_connected_cluster_arm_id_telemetry_context(
    cmd: CLICommand,
    resource_group_name: str,
    cluster_name: str,
    subscription_id: str | None = None,
) -> str:
    subscription_id = subscription_id or get_subscription_id(cmd.cli_ctx)
    arm_id = build_connected_cluster_arm_id(
        subscription_id, resource_group_name, cluster_name
    )
    cmd.cli_ctx.data[consts.Connected_Cluster_Arm_Id_Telemetry_Context_Key] = arm_id
    telemetry.set_debug_info(consts.Connected_Cluster_Arm_Id_Telemetry_Property, arm_id)
    return arm_id


def add_connectedk8s_telemetry_event(
    cmd: CLICommand | None, properties: dict[str, Any]
) -> None:
    event_properties = properties.copy()
    if cmd is not None:
        arm_id = cmd.cli_ctx.data.get(
            consts.Connected_Cluster_Arm_Id_Telemetry_Context_Key
        )
        if arm_id:
            event_properties[consts.Connected_Cluster_Arm_Id_Telemetry_Property] = (
                arm_id
            )
    telemetry.add_extension_event("connectedk8s", event_properties)


def report_connectedk8s_diagnostic(
    cmd: CLICommand | None,
    error: errors.ArcError,
    *,
    exception: BaseException | None = None,
    user_fault: bool = False,
    telemetry_properties: dict[str, Any] | None = None,
    fault_type: str | None = None,
    **context: object,
) -> str:
    """Report one standardized diagnostic to telemetry without raising it."""
    message = error.format(**context)
    telemetry_message = message.replace("'", "")
    properties = (telemetry_properties or {}).copy()
    properties.update(
        {
            consts.Telemetry_Error_Code_Key: error.code,
            consts.Telemetry_Error_Fault_Type_Key: fault_type or error.fault_type,
            consts.Telemetry_Error_Name_Key: error.name,
            consts.Telemetry_Error_Message_Key: telemetry_message,
        }
    )
    if error.tsg_link:
        properties[consts.Telemetry_Error_Tsg_Link_Key] = error.tsg_link
    add_connectedk8s_telemetry_event(cmd, properties)

    if user_fault:
        telemetry.set_user_fault()
    telemetry.set_exception(
        exception=exception if exception is not None else Exception(message),
        fault_type=fault_type or error.fault_type,
        summary=telemetry_message,
    )
    return message


def report_connectedk8s_error(
    cmd: CLICommand | None,
    error: errors.ArcError,
    *,
    exception: BaseException | None = None,
    user_fault: bool = False,
    telemetry_properties: dict[str, Any] | None = None,
    fault_type: str | None = None,
    **context: object,
) -> AzCLIError:
    """Report one standardized error to telemetry and return its console exception."""
    report_connectedk8s_diagnostic(
        cmd,
        error,
        exception=exception,
        user_fault=user_fault,
        telemetry_properties=telemetry_properties,
        fault_type=fault_type,
        **context,
    )
    return error.as_error(**context)


def report_helm_timeout_error(
    cmd: CLICommand | None, report: HelmTimeoutReport
) -> AzCLIError:
    """Report and build the console exception for a classified Helm timeout."""
    message = report.error.format(details=report.details)
    telemetry_properties = report.telemetry_properties.copy()
    telemetry_properties.update(
        {
            consts.Telemetry_Onboarding_Error_Type_Key: report.error.fault_type,
            consts.Telemetry_Onboarding_Error_Message_Key: message,
        }
    )
    telemetry.set_error_type("CLIInternalError")
    return report_connectedk8s_error(
        cmd,
        report.error,
        exception=Exception(message),
        user_fault=report.user_fault,
        telemetry_properties=telemetry_properties,
        details=report.details,
    )


def ensure_correlation_id(cmd: CLICommand, log_prefix: str = "connectedk8s") -> str:
    """Ensure ``x-ms-correlation-request-id`` is present for this command session."""
    headers = cmd.cli_ctx.data.setdefault("headers", {})
    existing = headers.get(consts.Correlation_Request_Id_Header)
    if existing:
        correlation_id = str(existing)
    else:
        correlation_id = str(uuid.uuid4())
        headers[consts.Correlation_Request_Id_Header] = correlation_id
    telemetry.set_debug_info(f"{log_prefix} correlation id is ", correlation_id)
    logger.info("%s session correlationId: %s", log_prefix, correlation_id)
    return correlation_id


def get_mcr_path(active_directory_endpoint: str) -> str:
    active_directory_array = active_directory_endpoint.split(".")

    # For US Government and China clouds, use public mcr
    if active_directory_endpoint.endswith((".us", ".cn")):
        return "mcr.microsoft.com"

    # Default MCR postfix
    mcr_postfix = "com"
    # special cases for USSec, exclude part of suffix
    if len(active_directory_array) == 4 and active_directory_array[2] == "microsoft":
        mcr_postfix = active_directory_array[3].strip("/")
    # special case for USNat
    elif len(active_directory_array) == 5:
        mcr_postfix = (
            active_directory_array[2]
            + "."
            + active_directory_array[3]
            + "."
            + active_directory_array[4].strip("/")
        )

    mcr_url = f"mcr.microsoft.{mcr_postfix}"
    return mcr_url


def validate_connect_rp_location(cmd: CLICommand, location: str) -> None:
    subscription_id = (
        os.getenv("AZURE_SUBSCRIPTION_ID")
        if os.getenv("AZURE_ACCESS_TOKEN")
        else get_subscription_id(cmd.cli_ctx)
    )
    rp_locations = []
    resourceClient = resource_providers_client(
        cmd.cli_ctx, subscription_id=subscription_id
    )

    try:
        providerDetails = resourceClient.get("Microsoft.Kubernetes")
    except Exception as e:  # pylint: disable=broad-exception-caught
        arm_exception_handler(
            e,
            consts.Get_ResourceProvider_Fault_Type,
            "Failed to fetch resource provider details",
        )

    for resourceTypes in providerDetails.resource_types:  # type: ignore[union-attr]
        if resourceTypes.resource_type == "connectedClusters":
            rp_locations = [
                location.replace(" ", "").lower()
                for location in resourceTypes.locations  # type: ignore[union-attr]
            ]
            if location.lower() not in rp_locations:
                telemetry.set_exception(
                    exception=Exception("Location not supported"),
                    fault_type=consts.Invalid_Location_Fault_Type,
                    summary="Provided location is not supported for creating connected clusters",
                )
                raise ArgumentUsageError(
                    "Connected cluster resource creation is supported only in the following locations: "
                    + ", ".join(map(str, rp_locations)),
                    recommendation="Use the --location flag to specify one of these locations.",
                )
            break


def validate_custom_token(
    cmd: CLICommand, resource_group_name: str, location: str | None
) -> tuple[bool, str | None]:
    print(f"Step: {get_utctimestring()}: Validating custom access token")
    if os.getenv("AZURE_ACCESS_TOKEN"):
        if os.getenv("AZURE_SUBSCRIPTION_ID") is None:
            telemetry.set_exception(
                exception=Exception(
                    "Required environment variable SubscriptionId not set, for custom Azure access token"
                ),
                fault_type=consts.Custom_Access_Token_Env_Var_Sub_Id_Missing_Fault_Type,
                summary="Required environment variable SubscriptionId not set, for custom Azure access token",
            )
            raise ValidationError(
                "Environment variable 'AZURE_SUBSCRIPTION_ID' should be set when custom access token is enabled."
            )
        if os.getenv("AZURE_TENANT_ID") is None:
            telemetry.set_exception(
                exception=Exception(
                    "Required environment variable TenantId not set, for custom Azure access token"
                ),
                fault_type=consts.Custom_Access_Token_Env_Var_Tenant_Id_Missing_Fault_Type,
                summary="Required environment variable TenantId not set, for custom Azure access token",
            )
            raise ValidationError(
                "Environment variable 'AZURE_TENANT_ID' should be set when custom access token is enabled."
            )
        if location is None:
            try:
                resource_client = cf_resource_groups(
                    cmd.cli_ctx, os.getenv("AZURE_SUBSCRIPTION_ID")
                )
                rg = resource_client.get(resource_group_name)
                location = rg.location
            except Exception as ex:  # pylint: disable=broad-exception-caught
                telemetry.set_exception(
                    exception=ex,
                    fault_type=consts.Location_Fetch_Fault_Type,
                    summary="Unable to fetch location from resource group",
                )
                raise ValidationError(
                    f"Unable to fetch location from resource group: '{ex}'"
                ) from ex
        return True, location
    return False, location


def get_chart_path(
    registry_path: str,
    kube_config: str | None,
    kube_context: str | None,
    helm_client_location: str,
    chart_folder_name: str = "AzureArcCharts",
    chart_name: str = "azure-arc-k8sagents",
    new_path: bool = True,
    cmd: CLICommand | None = None,
) -> str:
    print(f"Step: {get_utctimestring()}: Determine Helmchart Export Path")
    # Exporting Helm chart
    chart_export_path = os.path.join(
        os.path.expanduser("~"), ".azure", chart_folder_name
    )
    try:
        if os.path.isdir(chart_export_path):
            shutil.rmtree(chart_export_path)
    except OSError:
        logger.warning(
            "Unable to cleanup the %s already present on the machine. In case of failure, please cleanup "
            "the directory '%s' and try again.",
            chart_folder_name,
            chart_export_path,
        )

    pull_helm_chart(
        registry_path,
        chart_export_path,
        kube_config,
        kube_context,
        helm_client_location,
        new_path,
        chart_name,
        cmd=cmd,
    )

    # Returning helm chart path
    helm_chart_path = os.path.join(chart_export_path, chart_name)
    if chart_folder_name == consts.Pre_Onboarding_Helm_Charts_Folder_Name:
        chart_path = helm_chart_path
    else:
        chart_path = os.getenv("HELMCHART", helm_chart_path)

    if not os.path.isdir(chart_path):
        details = f"Expected exported chart directory was not found: {chart_path}"
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_CHART_EXPORT_FAILED,
            exception=FileNotFoundError(details),
            details=details,
        )

    return chart_path


def pull_helm_chart(
    registry_path: str,
    chart_export_path: str,
    kube_config: str | None,
    kube_context: str | None,
    helm_client_location: str,
    new_path: bool,
    chart_name: str = "azure-arc-k8sagents",
    retry_count: int = 5,
    retry_delay: int = 3,
    cmd: CLICommand | None = None,
) -> None:
    chart_url = registry_path.split(":")[0]
    chart_version = registry_path.split(":")[1]

    if new_path:
        # Version check for stable release train (chart_version will be in X.Y.Z format as opposed to X.Y.Z-NONSTABLE)
        if "-" not in chart_version and (
            version.parse(chart_version) < version.parse("1.14.0")
        ):
            error_summary = "This CLI version does not support upgrading to Agents versions older than v1.14"
            telemetry.set_exception(
                exception=Exception("Operation not supported on older Agents"),
                fault_type=consts.Operation_Not_Supported_Fault_Type,
                summary=error_summary,
            )
            raise ClientRequestError(
                error_summary,
                recommendation="Please select an agent-version >= v1.14 to upgrade to using 'az connectedk8s upgrade "
                "-g <rg_name> -n <cluster_name> --agent-version <at-least-1.14>'.",
            )

        base_path = os.path.dirname(chart_url)
        image_name = os.path.basename(chart_url)
        chart_url = base_path + "/v2/" + image_name

    print(
        f"Step: {get_utctimestring()}: Pulling HelmChart: {chart_url}, Version: {chart_version}"
    )

    cmd_helm_chart_pull = [
        helm_client_location,
        "pull",
        "oci://" + chart_url,
        "--untar",
        "--untardir",
        chart_export_path,
        "--version",
        chart_version,
    ]
    if kube_config:
        cmd_helm_chart_pull.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_chart_pull.extend(["--kube-context", kube_context])
    for i in range(retry_count):
        response_helm_chart_pull = subprocess.Popen(
            cmd_helm_chart_pull, stdout=PIPE, stderr=PIPE
        )
        _, error_helm_chart_pull = response_helm_chart_pull.communicate()
        if response_helm_chart_pull.returncode != 0:
            if i == retry_count - 1:
                error = process_helm_error_detail(
                    error_helm_chart_pull.decode("ascii", errors="replace")
                )
                raise report_connectedk8s_error(
                    cmd,
                    errors.HELM_CHART_PULL_FAILED,
                    exception=Exception(error),
                    details=(
                        f"Unable to pull {chart_name} from registry "
                        f"'{registry_path}': {error}"
                    ),
                )
            time.sleep(retry_delay)
        else:
            break


def save_cluster_diagnostic_checks_pod_description(
    corev1_api_instance: CoreV1Api,
    kubectl_client_location: str,
    kube_config: str | None,
    kube_context: str | None,
    filepath_with_timestamp: str,
    storage_space_available: bool,
) -> None:
    try:
        job_name = "cluster-diagnostic-checks-job"
        all_pods = corev1_api_instance.list_namespaced_pod("azure-arc-release")
        # Traversing through all agents
        for each_pod in all_pods.items:
            # Fetching the current Pod name and creating a folder with that name inside the timestamp folder
            pod_name = each_pod.metadata.name
            if pod_name.startswith(job_name):
                describe_job_pod = [
                    kubectl_client_location,
                    "describe",
                    "pod",
                    pod_name,
                    "-n",
                    "azure-arc-release",
                ]
                if kube_config:
                    describe_job_pod.extend(["--kubeconfig", kube_config])
                if kube_context:
                    describe_job_pod.extend(["--context", kube_context])
                response_describe_job_pod = Popen(
                    describe_job_pod, stdout=PIPE, stderr=PIPE
                )
                output_describe_job_pod, error_describe_job_pod = (
                    response_describe_job_pod.communicate()
                )
                if response_describe_job_pod.returncode == 0:
                    pod_description = output_describe_job_pod.decode()
                    if storage_space_available:
                        dns_check_path = os.path.join(
                            filepath_with_timestamp,
                            "cluster_diagnostic_checks_pod_description.txt",
                        )
                        with open(dns_check_path, "w+", encoding="utf-8") as f:
                            f.write(pod_description)
                else:
                    telemetry.set_exception(
                        exception=Exception(error_describe_job_pod.decode("ascii")),
                        fault_type=consts.Cluster_Diagnostic_Checks_Pod_Description_Save_Failed,
                        summary="Failed to save cluster diagnostic checks pod description in the local machine",
                    )
    except OSError as e:
        if "[Errno 28]" in str(e):
            storage_space_available = False
            telemetry.set_exception(
                exception=e,
                fault_type=consts.No_Storage_Space_Available_Fault_Type,
                summary="No space left on device",
            )
            shutil.rmtree(filepath_with_timestamp, ignore_errors=False)
        else:
            logger.exception(
                "An exception has occured while saving the cluster diagnostic checks "
                "pod description in the local machine."
            )
            telemetry.set_exception(
                exception=e,
                fault_type=consts.Cluster_Diagnostic_Checks_Pod_Description_Save_Failed,
                summary="Error occured while saving the cluster diagnostic checks pod description in the local machine",
            )

    # To handle any exception that may occur during the execution
    except (ValueError, TypeError) as e:
        logger.exception(
            "An exception has occured while saving the cluster diagnostic checks pod "
            "description in the local machine."
        )
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Cluster_Diagnostic_Checks_Pod_Description_Save_Failed,
            summary="Error occured while saving the cluster diagnostic checks pod description in the local machine",
        )


def check_cluster_DNS(
    dns_check_log: str,
    filepath_with_timestamp: str,
    storage_space_available: bool,
    diagnoser_output: list[str],
) -> tuple[str, bool]:
    try:
        if consts.DNS_Check_Result_String not in dns_check_log:
            return consts.Diagnostic_Check_Incomplete, storage_space_available
        formatted_dns_log = dns_check_log.replace("\t", "")
        # Validating if DNS is working or not and displaying proper result
        # These are standard error strings from DNS tools (nslookup/dig) indicating resolution failures
        if (  # pylint: disable=too-many-boolean-expressions
            "NXDOMAIN" in formatted_dns_log
            or "SERVFAIL" in formatted_dns_log
            or "connection timed out" in formatted_dns_log
            or "no servers could be reached" in formatted_dns_log
            or "communications error" in formatted_dns_log
            or "timed out" in formatted_dns_log
        ):
            # Determine specific DNS failure type for telemetry
            dns_error_type = "unknown"
            if "NXDOMAIN" in formatted_dns_log:
                dns_error_type = "NXDOMAIN"
            elif "SERVFAIL" in formatted_dns_log:
                dns_error_type = "SERVFAIL"
            elif "no servers could be reached" in formatted_dns_log:
                dns_error_type = "no-servers-reachable"
            elif (
                "connection timed out" in formatted_dns_log
                or "timed out" in formatted_dns_log
            ):
                dns_error_type = "timeout"
            elif "communications error" in formatted_dns_log:
                dns_error_type = "communications-error"

            logger.warning(
                "Error: We found an issue with the DNS resolution on your cluster. For details about debugging DNS "
                "issues visit 'https://kubernetes.io/docs/tasks/administer-cluster/dns-debugging-resolution/'.\n"
            )
            diagnoser_output.append(
                f"Error: DNS resolution failed (type={dns_error_type}). "
                "For details visit 'https://kubernetes.io/docs/tasks/administer-cluster/dns-debugging-resolution/'.\n"
            )
            if storage_space_available:
                dns_check_path = os.path.join(filepath_with_timestamp, consts.DNS_Check)
                with open(dns_check_path, "w+", encoding="utf-8") as dns:
                    dns.write(
                        formatted_dns_log
                        + "\nWe found an issue with the DNS resolution on your cluster."
                    )
            telemetry.set_exception(
                exception=Exception("DNS resolution check failed in the cluster"),
                fault_type=consts.DNS_Check_Failed,
                summary="DNS check failed in the cluster",
            )
            return consts.Diagnostic_Check_Failed, storage_space_available

        if storage_space_available:
            dns_check_path = os.path.join(filepath_with_timestamp, consts.DNS_Check)
            with open(dns_check_path, "w+", encoding="utf-8") as dns:
                dns.write(
                    formatted_dns_log + "\nCluster DNS check passed successfully."
                )

        return consts.Diagnostic_Check_Passed, storage_space_available

    # For handling storage or OS exception that may occur during the execution
    except OSError as e:
        if "[Errno 28]" in str(e):
            storage_space_available = False
            telemetry.set_exception(
                exception=e,
                fault_type=consts.No_Storage_Space_Available_Fault_Type,
                summary="No space left on device",
            )
            shutil.rmtree(filepath_with_timestamp, ignore_errors=False)
        else:
            logger.exception(
                "An exception has occured while performing the DNS check on the "
                "cluster."
            )
            telemetry.set_exception(
                exception=e,
                fault_type=consts.Cluster_DNS_Check_Fault_Type,
                summary="Error occured while performing cluster DNS check",
            )
            diagnoser_output.append(
                "An exception has occured while performing the DNS check on the cluster. "
                f"Exception: {e}\n"
            )

    # To handle any exception that may occur during the execution
    except (ValueError, TypeError) as e:
        logger.exception(
            "An exception has occured while performing the DNS check on the cluster."
        )
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Cluster_DNS_Check_Fault_Type,
            summary="Error occured while performing cluster DNS check",
        )
        diagnoser_output.append(
            "An exception has occured while performing the DNS check on the cluster. "
            f"Exception: {e}\n"
        )

    return consts.Diagnostic_Check_Incomplete, storage_space_available


# pylint: disable=too-many-return-statements
# Outbound connectivity check returns different results based on connection state
def check_cluster_outbound_connectivity(  # pylint: disable=too-many-branches,too-many-nested-blocks
    outbound_connectivity_check_log: str,
    filepath_with_timestamp: str,
    storage_space_available: bool,
    diagnoser_output: list[str],
    outbound_connectivity_check_for: str = "pre-onboarding-inspector",
    cmd: CLICommand | None = None,
) -> tuple[str, bool]:
    try:
        if outbound_connectivity_check_for == "pre-onboarding-inspector":
            if (
                consts.Outbound_Connectivity_Check_Result_String
                not in outbound_connectivity_check_log
            ):
                return consts.Diagnostic_Check_Incomplete, storage_space_available

            Outbound_Connectivity_Log_For_Cluster_Connect = (
                outbound_connectivity_check_log.split("  ")[0]
            )
            # extracting the endpoints for cluster connect feature
            Cluster_Connect_Precheck_Endpoint_Url = (
                Outbound_Connectivity_Log_For_Cluster_Connect.split(" : ")[1]
            )
            # extracting the obo endpoint response code from outbound connectivity check
            Cluster_Connect_Precheck_Endpoint_response_code = (
                Outbound_Connectivity_Log_For_Cluster_Connect.split(" : ")[2]
            )

            if Cluster_Connect_Precheck_Endpoint_response_code != "000":
                # Emit informational telemetry for 4xx/5xx (e.g., proxy block)
                if Cluster_Connect_Precheck_Endpoint_response_code.startswith(
                    ("4", "5")
                ):
                    add_connectedk8s_telemetry_event(
                        cmd,
                        {
                            consts.Telemetry_Onboarding_Error_Type_Key: consts.Outbound_Connectivity_Non2xx_Response_Type,
                            consts.Telemetry_Onboarding_Error_Message_Key: (
                                f"endpoint={Cluster_Connect_Precheck_Endpoint_Url}; "
                                f"code={Cluster_Connect_Precheck_Endpoint_response_code}; "
                                f"target=cluster-connect"
                            ),
                        },
                    )
                if storage_space_available:
                    cluster_connect_outbound_connectivity_check_path = os.path.join(
                        filepath_with_timestamp,
                        consts.Outbound_Network_Connectivity_Check_for_cluster_connect,
                    )
                    with open(
                        cluster_connect_outbound_connectivity_check_path,
                        "w+",
                        encoding="utf-8",
                    ) as outbound:
                        outbound.write(
                            "Response code "
                            + Cluster_Connect_Precheck_Endpoint_response_code
                            + "\nOutbound network connectivity check to cluster connect precheck endpoints "
                            "passed successfully."
                        )
            else:
                logger.warning(
                    "The outbound network connectivity check has failed for the "
                    "endpoint - %s\n"
                    'This will affect the "cluster-connect" feature. If you are planning to use '
                    '"cluster-connect" functionality, please ensure outbound connectivity to the '
                    "above endpoint.\n",
                    Cluster_Connect_Precheck_Endpoint_Url,
                )
                telemetry.set_user_fault()
                telemetry.set_exception(
                    exception=Exception(
                        "Outbound network connectivity check failed for the Cluster Connect endpoint"
                    ),
                    fault_type=consts.Outbound_Connectivity_Check_Failed_For_Cluster_Connect,
                    summary="Outbound network connectivity check failed for the Cluster Connect precheck endpoint",
                )
                if storage_space_available:
                    cluster_connect_outbound_connectivity_check_path = os.path.join(
                        filepath_with_timestamp,
                        consts.Outbound_Network_Connectivity_Check_for_cluster_connect,
                    )
                    with open(
                        cluster_connect_outbound_connectivity_check_path,
                        "w+",
                        encoding="utf-8",
                    ) as outbound:
                        outbound.write(
                            "Response code "
                            + Cluster_Connect_Precheck_Endpoint_response_code
                            + "\nOutbound connectivity failed for the endpoint:"
                            + Cluster_Connect_Precheck_Endpoint_Url
                            + " ,this is an optional endpoint needed for cluster-connect feature."
                        )

            Onboarding_Precheck_Endpoint_outbound_connectivity_response = (
                outbound_connectivity_check_log[-1:-4:-1]
            )
            Onboarding_Precheck_Endpoint_outbound_connectivity_response = (
                Onboarding_Precheck_Endpoint_outbound_connectivity_response[::-1]
            )

            # Validating if outbound connectiivty is working or not and displaying proper result
            if Onboarding_Precheck_Endpoint_outbound_connectivity_response != "000":
                # Emit informational telemetry for 4xx/5xx (e.g., proxy block)
                if Onboarding_Precheck_Endpoint_outbound_connectivity_response.startswith(
                    ("4", "5")
                ):
                    add_connectedk8s_telemetry_event(
                        cmd,
                        {
                            consts.Telemetry_Onboarding_Error_Type_Key: consts.Outbound_Connectivity_Non2xx_Response_Type,
                            consts.Telemetry_Onboarding_Error_Message_Key: (
                                f"code={Onboarding_Precheck_Endpoint_outbound_connectivity_response}; "
                                f"target=onboarding"
                            ),
                        },
                    )
                if storage_space_available:
                    outbound_connectivity_check_path = os.path.join(
                        filepath_with_timestamp,
                        consts.Outbound_Network_Connectivity_Check_for_onboarding,
                    )
                    with open(
                        outbound_connectivity_check_path, "w+", encoding="utf-8"
                    ) as outbound:
                        outbound.write(
                            "Response code "
                            + Onboarding_Precheck_Endpoint_outbound_connectivity_response
                            + "\nOutbound network connectivity check to the onboarding precheck endpoint "
                            "passed successfully."
                        )
                return consts.Diagnostic_Check_Passed, storage_space_available

            outbound_connectivity_failed_warning_message = (
                "Error: We found an issue with outbound network connectivity from the cluster to the endpoints "
                "required for onboarding.\nPlease ensure to meet the following network requirements "
                + consts.Doc_Network_Requirements_Url
                + "\nIf your cluster is behind an outbound proxy server, "
                " please ensure that you have passed proxy parameters during the onboarding of your cluster.\n"
                "For more details visit "
                + consts.Doc_Quick_Start_Outbound_Proxy_Url
                + " \n"
            )
            logger.warning(outbound_connectivity_failed_warning_message)
            telemetry.set_user_fault()

            # Extract failed endpoint URLs for telemetry diagnostics
            failed_endpoints: list[str] = []
            failed_endpoint_details: list[str] = []
            try:
                log_parts = outbound_connectivity_check_log.split("  ")
                for part in log_parts:
                    if consts.Outbound_Connectivity_Check_Result_String in part:
                        segments = part.split(" : ")
                        if len(segments) >= 3:
                            endpoint = segments[1].strip()
                            code = segments[2].strip()
                            if code == "000":
                                failed_endpoints.append(endpoint)
                                failed_endpoint_details.append(
                                    f"{endpoint} (code=000, no HTTP response - "
                                    "likely firewall drop, proxy block, or network timeout)"
                                )
                            # Non-2xx (4xx/5xx) responses are treated as reachable and should not be labeled as failures here.
            except (IndexError, ValueError):
                pass

            # Include endpoint details in diagnoser_output for telemetry capture
            if failed_endpoint_details:
                details_str = "; ".join(failed_endpoint_details)
                diagnoser_output.append(
                    f"Error: Outbound connectivity failed for: {details_str}"
                )
            else:
                diagnoser_output.append(outbound_connectivity_failed_warning_message)
            if storage_space_available:
                outbound_connectivity_check_path = os.path.join(
                    filepath_with_timestamp,
                    consts.Outbound_Network_Connectivity_Check_for_onboarding,
                )
                with open(
                    outbound_connectivity_check_path, "w+", encoding="utf-8"
                ) as outbound:
                    outbound.write(
                        "Response code "
                        + Onboarding_Precheck_Endpoint_outbound_connectivity_response
                        + "\nWe found an issue with Outbound network connectivity from the cluster "
                        "required for onboarding."
                    )
            telemetry.set_exception(
                exception=Exception(
                    "Outbound network connectivity check failed for onboarding"
                ),
                fault_type=consts.Outbound_Connectivity_Check_Failed_For_Onboarding,
                summary="Outbound network connectivity check for onboarding failed in the cluster",
            )
            return consts.Diagnostic_Check_Failed, storage_space_available

        if outbound_connectivity_check_for == "troubleshoot":
            outbound_connectivity_response = outbound_connectivity_check_log[-1:-4:-1]
            outbound_connectivity_response = outbound_connectivity_response[::-1]
            if (
                consts.Outbound_Connectivity_Check_Result_String
                not in outbound_connectivity_check_log
            ):
                return consts.Diagnostic_Check_Incomplete, storage_space_available

            if outbound_connectivity_response != "000":
                # Emit informational telemetry for 4xx/5xx (e.g., proxy block)
                if outbound_connectivity_response.startswith(("4", "5")):
                    add_connectedk8s_telemetry_event(
                        cmd,
                        {
                            consts.Telemetry_Onboarding_Error_Type_Key: consts.Outbound_Connectivity_Non2xx_Response_Type,
                            consts.Telemetry_Onboarding_Error_Message_Key: (
                                f"code={outbound_connectivity_response}; "
                                f"target=troubleshoot"
                            ),
                        },
                    )
                if storage_space_available:
                    outbound_connectivity_check_path = os.path.join(
                        filepath_with_timestamp,
                        consts.Outbound_Network_Connectivity_Check,
                    )
                    with open(
                        outbound_connectivity_check_path, "w+", encoding="utf-8"
                    ) as outbound:
                        outbound.write(
                            "Response code "
                            + outbound_connectivity_response
                            + "\nOutbound network connectivity check passed successfully."
                        )
                return consts.Diagnostic_Check_Passed, storage_space_available

            outbound_connectivity_failed_warning_message = (
                "Error: We found an issue with outbound network connectivity from the cluster.\nPlease ensure to "
                "meet the following network requirements '"
                + consts.Doc_Network_Requirements_Url
                + " \nIf your cluster is behind an outbound proxy server, please ensure that you have passed proxy "
                "parameters during the onboarding of your cluster.\nFor more details visit "
                + consts.Doc_Quick_Start_Outbound_Proxy_Url
                + " \n"
            )
            logger.warning(outbound_connectivity_failed_warning_message)
            diagnoser_output.append(outbound_connectivity_failed_warning_message)
            if storage_space_available:
                outbound_connectivity_check_path = os.path.join(
                    filepath_with_timestamp, consts.Outbound_Network_Connectivity_Check
                )
                with open(
                    outbound_connectivity_check_path, "w+", encoding="utf-8"
                ) as outbound:
                    outbound.write(
                        "Response code "
                        + outbound_connectivity_response
                        + "\nWe found an issue with Outbound network connectivity from the cluster."
                    )
            telemetry.set_exception(
                exception=Exception("Outbound network connectivity check failed"),
                fault_type=consts.Outbound_Connectivity_Check_Failed,
                summary="Outbound network connectivity check failed in the cluster",
            )
            return consts.Diagnostic_Check_Failed, storage_space_available

    # For handling storage or OS exception that may occur during the execution
    except OSError as e:
        if "[Errno 28]" in str(e):
            storage_space_available = False
            telemetry.set_exception(
                exception=e,
                fault_type=consts.No_Storage_Space_Available_Fault_Type,
                summary="No space left on device",
            )
            shutil.rmtree(filepath_with_timestamp, ignore_errors=False)
        else:
            logger.exception(
                "An exception has occured while performing the outbound connectivity "
                "check on the cluster."
            )
            telemetry.set_exception(
                exception=e,
                fault_type=consts.Outbound_Connectivity_Check_Fault_Type,
                summary="Error occured while performing outbound connectivity check in the cluster",
            )
            diagnoser_output.append(
                "An exception has occured while performing the outbound connectivity check on the cluster. "
                f"Exception: {e}\n"
            )

    # To handle any exception that may occur during the execution
    except (ValueError, TypeError) as e:
        logger.exception(
            "An exception has occured while performing the outbound connectivity check "
            "on the cluster."
        )
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Outbound_Connectivity_Check_Fault_Type,
            summary="Error occured while performing outbound connectivity check in the cluster",
        )
        diagnoser_output.append(
            "An exception has occured while performing the outbound connectivity check on the cluster. "
            f"Exception: {e}\n"
        )

    return consts.Diagnostic_Check_Incomplete, storage_space_available


def create_folder_diagnosticlogs(time_stamp: str, folder_name: str) -> tuple[str, bool]:
    print(
        f"Step: {get_utctimestring()}: Creating folder for Cluster Diagnostic Checks Logs"
    )
    try:
        # Fetching path to user directory to create the arc diagnostic folder
        home_dir = os.path.expanduser("~")
        filepath = os.path.join(home_dir, ".azure", folder_name)
        # Creating Diagnostic folder and its subfolder with the given timestamp and cluster name to store all the logs
        with contextlib.suppress(FileExistsError):
            os.mkdir(filepath)
        filepath_with_timestamp = os.path.join(filepath, time_stamp)
        try:
            os.mkdir(filepath_with_timestamp)
        except FileExistsError:
            # Deleting the folder if present with the same timestamp to prevent overriding in the same folder and then
            #  creating it again
            shutil.rmtree(filepath_with_timestamp, ignore_errors=True)
            os.mkdir(filepath_with_timestamp)

        return filepath_with_timestamp, True

    # For handling storage or OS exception that may occur during the execution
    except OSError as e:
        if "[Errno 28]" in str(e):
            shutil.rmtree(filepath_with_timestamp, ignore_errors=False)
            telemetry.set_exception(
                exception=e,
                fault_type=consts.No_Storage_Space_Available_Fault_Type,
                summary="No space left on device",
            )
            return "", False
        logger.exception(
            "An exception has occured while creating the diagnostic logs folder in "
            "your local machine."
        )
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Diagnostics_Folder_Creation_Failed_Fault_Type,
            summary="Error while trying to create diagnostic logs folder",
        )
        return "", False

    # To handle any exception that may occur during the execution
    except (ValueError, TypeError) as e:
        logger.exception(
            "An exception has occured while creating the diagnostic logs folder in "
            "your local machine."
        )
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Diagnostics_Folder_Creation_Failed_Fault_Type,
            summary="Error while trying to create diagnostic logs folder",
        )
        return "", False


def add_helm_repo(
    kube_config: str | None,
    kube_context: str | None,
    helm_client_location: str,
    cmd: CLICommand | None = None,
) -> None:
    print(f"Step: {get_utctimestring()}: Adding Helm Repo")
    repo_name = os.environ["HELMREPONAME"]
    repo_url = os.environ["HELMREPOURL"]
    cmd_helm_repo = [helm_client_location, "repo", "add", repo_name, repo_url]
    if kube_config:
        cmd_helm_repo.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_repo.extend(["--kube-context", kube_context])
    response_helm_repo = Popen(cmd_helm_repo, stdout=PIPE, stderr=PIPE)
    _, error_helm_repo = response_helm_repo.communicate()
    if response_helm_repo.returncode != 0:
        error = process_helm_error_detail(
            error_helm_repo.decode("ascii", errors="replace")
        )
        details = f"Helm repository could not be added: {error}"
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_REPO_ADD_FAILED,
            exception=Exception(details),
            details=details,
        )


def get_helm_registry(
    cmd: CLICommand, config_dp_endpoint: str, release_train_custom: str | None = None
) -> str:
    print(f"Step: {get_utctimestring()}: Getting HelmPackagePath from Arc DataPlane")
    # Setting uri
    api_version = "2019-11-01-preview"
    chart_location_url_segment = (
        f"azure-arc-k8sagents/GetLatestHelmPackagePath?api-version={api_version}"
    )
    release_train = os.getenv("RELEASETRAIN") if os.getenv("RELEASETRAIN") else "stable"
    chart_location_url = f"{config_dp_endpoint}/{chart_location_url_segment}"
    if release_train_custom:
        release_train = release_train_custom
    uri_parameters = [f"releaseTrain={release_train}"]
    resource = cmd.cli_ctx.cloud.endpoints.active_directory_resource_id
    headers = None
    if os.getenv("AZURE_ACCESS_TOKEN"):
        headers = [f"Authorization=Bearer {os.getenv('AZURE_ACCESS_TOKEN')}"]
    # Sending request with retries
    r = send_request_with_retries(
        cmd.cli_ctx,
        "post",
        chart_location_url,
        headers=headers,
        fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
        summary="Error while fetching helm chart registry path",
        uri_parameters=uri_parameters,
        resource=resource,
    )
    if r.content:
        try:
            repository_path: str = r.json().get("repositoryPath")
            return repository_path
        except (ValueError, KeyError, AttributeError) as e:
            telemetry.set_exception(
                exception=e,
                fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
                summary="Error while fetching helm chart registry path",
            )
            raise CLIInternalError(
                f"Error while fetching helm chart registry path from JSON response: {e}"
            ) from e
    else:
        telemetry.set_exception(
            exception=Exception("No content in response"),
            fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
            summary="No content in acr path response",
        )
        raise CLIInternalError("No content was found in helm registry path response.")


def get_helm_values(
    cmd: CLICommand,
    config_dp_endpoint: str,
    release_train_custom: str | None,
    connected_cluster: ConnectedCluster,
) -> dict[str, Any]:
    # Setting uri
    api_version = "2024-07-01-preview"
    chart_location_url_segment = (
        f"azure-arc-k8sagents/GetHelmSettings?api-version={api_version}"
    )
    release_train = os.getenv("RELEASETRAIN", "stable")
    chart_location_url = f"{config_dp_endpoint}/{chart_location_url_segment}"
    dp_request_identity = connected_cluster.identity
    identity = connected_cluster.id
    request_dict = connected_cluster.as_dict()
    request_dict["identity"]["tenantId"] = dp_request_identity.tenant_id
    request_dict["identity"]["principalId"] = dp_request_identity.principal_id
    request_dict["id"] = identity
    request_body = json.dumps(request_dict)
    if release_train_custom:
        release_train = release_train_custom
    uri_parameters = [f"releaseTrain={release_train}"]
    resource = cmd.cli_ctx.cloud.endpoints.active_directory_resource_id
    headers = None
    if os.getenv("AZURE_ACCESS_TOKEN"):
        headers = [f"Authorization=Bearer {os.getenv('AZURE_ACCESS_TOKEN')}"]
    # Sending request with retries
    r = send_request_with_retries(
        cmd.cli_ctx,
        "post",
        chart_location_url,
        headers=headers,
        fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
        summary="Error while fetching helm chart registry path",
        uri_parameters=uri_parameters,
        resource=resource,
        request_body=request_body,
    )
    if r.content:
        try:
            content: dict[str, Any] = r.json()
            return content
        except (ValueError, KeyError) as e:
            telemetry.set_exception(
                exception=e,
                fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
                summary="Error while fetching helm values from DP",
            )
            raise CLIInternalError(
                f"Error while fetching helm values from DP from JSON response: {e}"
            ) from e
    else:
        telemetry.set_exception(
            exception=Exception("No content in response"),
            fault_type=consts.Get_HelmRegistery_Path_Fault_Type,
            summary="No content in acr path response",
        )
        raise CLIInternalError("No content was found in helm registry path response.")


def health_check_dp(cmd: CLICommand, config_dp_endpoint: str) -> bool:
    # Setting uri
    api_version = "2024-07-01-preview"
    chart_location_url_segment = (
        f"azure-arc-k8sagents/healthCheck?api-version={api_version}"
    )
    chart_location_url = f"{config_dp_endpoint}/{chart_location_url_segment}"
    uri_parameters: list[str] = []
    resource = cmd.cli_ctx.cloud.endpoints.active_directory_resource_id
    headers = None
    if os.getenv("AZURE_ACCESS_TOKEN"):
        headers = [f"Authorization=Bearer {os.getenv('AZURE_ACCESS_TOKEN')}"]
    # Sending request with retries
    r = send_request_with_retries(
        cmd.cli_ctx,
        "post",
        chart_location_url,
        headers=headers,
        fault_type=consts.DP_Health_Check_Fault_Type,
        summary="Error while performing DP health check",
        uri_parameters=uri_parameters,
        resource=resource,
    )
    if r.status_code == 200:
        return True

    telemetry.set_exception(
        exception=Exception("Error while performing DP health check"),
        fault_type=consts.DP_Health_Check_Fault_Type,
        summary="Error while performing DP health check",
    )
    raise CLIInternalError("Error while performing DP health check")


def update_gateway_cluster_link(
    cmd: CLICommand,
    subscription_id: str,
    resource_group: str,
    cluster_name: str,
    gateway_resource_id: str | None = None,
) -> bool:
    """
    Associates or disassociates a gateway with a cluster.

    If `gateway_resource_id` is provided, performs association.
    If `gateway_resource_id` is None, performs disassociation.
    """
    api_version = "2025-02-19-preview"
    is_association = gateway_resource_id is not None
    resource = cmd.cli_ctx.cloud.endpoints.active_directory_resource_id
    url = consts.GATEWAY_ASSOCIATE_URL.format(
        subscription_id=subscription_id,
        resource_group=resource_group,
        cluster_name=cluster_name,
        api_version=api_version,
    )

    headers = ["Content-Type=application/json", "Accept=application/json"]

    token = os.getenv("AZURE_ACCESS_TOKEN")
    if token:
        headers.append(f"Authorization=Bearer {token}")

    operation_type = "association" if is_association else "disassociation"
    body = {
        "properties": {
            "gatewayProperties": {
                "gatewayResourceId": gateway_resource_id  # None in case of disassociation
            }
        }
    }
    response = send_request_with_retries(
        cmd.cli_ctx,
        method="put",
        url=url,
        headers=headers,
        fault_type=consts.GATEWAY_LINK_FAULT_TYPE,
        summary=f"Error during gateway {operation_type}",
        request_body=json.dumps(body),
        resource=resource,
    )

    if response.status_code == 200:
        # Use lazy interpolation to satisfy pylint W1203 and avoid eager string formatting.
        logger.info(
            "Gateway %s succeeded for cluster '%s' in resource group '%s'.",
            operation_type,
            cluster_name,
            resource_group,
        )
        return True

    telemetry.set_exception(
        exception=Exception(f"Gateway {operation_type} failed"),
        fault_type=consts.GATEWAY_LINK_FAULT_TYPE,
        summary=f"Gateway {operation_type} failed",
    )
    raise CLIInternalError(
        f"Gateway {operation_type} failed for cluster '{cluster_name}'."
    )


def send_request_with_retries(
    cli_ctx: AzCli,
    method: str,
    url: str,
    headers: list[str] | None,
    fault_type: str,
    summary: str,
    uri_parameters: list[str] | None = None,
    resource: str | None = None,
    retry_count: int = 5,
    retry_delay: int = 3,
    request_body: str | None = None,
) -> Response:
    response: Response
    for i in range(retry_count):
        try:
            response = send_raw_request(
                cli_ctx,
                method,
                url,
                headers=headers,
                uri_parameters=uri_parameters,
                resource=resource,
                body=request_body,
            )
            return response
        except Exception as e:  # pylint: disable=broad-exception-caught
            if i == retry_count - 1:
                telemetry.set_exception(
                    exception=e, fault_type=fault_type, summary=summary
                )
                raise CLIInternalError(
                    f"Error while fetching helm chart registry path: {e}"
                ) from e
            time.sleep(retry_delay)

    assert False


def arm_exception_handler(
    ex: Exception, fault_type: str, summary: str, return_if_not_found: bool = False
) -> None:
    if isinstance(ex, AuthenticationError):
        telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
        raise AzureResponseError(
            "Authentication error occured while making ARM request: "
            + str(ex)
            + f"\nSummary: {summary}"
        )

    if isinstance(ex, TokenExpiredError):
        telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
        raise AzureResponseError(
            "Token expiration error occured while making ARM request: "
            + str(ex)
            + f"\nSummary: {summary}"
        )

    if isinstance(ex, HttpOperationError):
        status_code = ex.response.status_code
        if status_code == 404 and return_if_not_found:
            return
        if status_code // 100 == 4:
            telemetry.set_user_fault()
        telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
        if status_code // 100 == 5:
            raise AzureInternalError(
                "Http operation error occured while making ARM request: "
                + str(ex)
                + f"\nSummary: {summary}"
            )
        raise AzureResponseError(
            "Http operation error occured while making ARM request: "
            + str(ex)
            + f"\nSummary: {summary}"
        )

    if isinstance(ex, MSRestValidationError):
        telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
        raise AzureResponseError(
            "Validation error occured while making ARM request: "
            + str(ex)
            + f"\nSummary: {summary}"
        )

    if isinstance(ex, HttpResponseError):
        status_code = ex.status_code
        if status_code == 404 and return_if_not_found:
            return
        if status_code and status_code // 100 == 4:
            telemetry.set_user_fault()
        telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
        if status_code and status_code // 100 == 5:
            raise AzureInternalError(
                "Http response error occured while making ARM request: "
                + str(ex)
                + f"\nSummary: {summary}"
            )
        raise AzureResponseError(
            "Http response error occured while making ARM request: "
            + str(ex)
            + f"\nSummary: {summary}"
        )

    if isinstance(ex, ResourceNotFoundError) and return_if_not_found:
        return

    telemetry.set_exception(exception=ex, fault_type=fault_type, summary=summary)
    raise ClientRequestError(
        "Error occured while making ARM request: " + str(ex) + f"\nSummary: {summary}"
    )


def kubernetes_exception_handler(
    ex: Exception,
    fault_type: str,
    summary: str,
    error_message: str = "Error occured while connecting to the kubernetes cluster: ",
    message_for_unauthorized_request: str = "The user does not have required privileges on the "
    "kubernetes cluster to deploy Azure Arc enabled Kubernetes agents. Please "
    "ensure you have cluster admin privileges on the cluster to onboard.",
    message_for_not_found: str = "The requested kubernetes resource was not found.",
    raise_error: bool = True,
) -> None:
    telemetry.set_user_fault()
    if isinstance(ex, ApiException):
        status_code = ex.status
        if status_code == 403:
            logger.warning(message_for_unauthorized_request)
        elif status_code == 404:
            logger.warning(message_for_not_found)
        else:
            logger.debug("Kubernetes Exception: ", exc_info=True)
        if raise_error:
            telemetry.set_exception(
                exception=ex, fault_type=fault_type, summary=summary
            )
            raise ValidationError(error_message + "\nError Response: " + str(ex.body))
    else:
        if raise_error:
            telemetry.set_exception(
                exception=ex, fault_type=fault_type, summary=summary
            )
            raise ValidationError(error_message + "\nError: " + str(ex))

        logger.debug("Kubernetes Exception", exc_info=True)


def validate_infrastructure_type(infra: str) -> str | None:
    for s in consts.Infrastructure_Enum_Values[1:]:  # First value is "auto"
        if s.lower() == infra.lower():
            return s
    return infra


def get_values_file() -> str | None:
    values_file = os.getenv("HELMVALUESPATH")
    if (values_file is not None) and (os.path.isfile(values_file)):
        logger.warning(
            "Values files detected. Reading additional helm parameters from same."
        )
        # trimming required for windows os
        if values_file.startswith(("'", '"')):
            values_file = values_file[1:]
        if values_file.endswith(("'", '"')):
            values_file = values_file[:-1]
        return values_file
    return None


def ensure_namespace_cleanup() -> None:
    print(
        f"Step: {get_utctimestring()}: Confirming '{consts.Arc_Namespace}' namespace got deleted."
    )
    api_instance = kube_client.CoreV1Api()
    timeout = time.time() + 180
    while True:
        if time.time() > timeout:
            telemetry.set_user_fault()
            logger.warning(
                "Namespace 'azure-arc' still in terminating state. Please ensure that you delete the "
                "'azure-arc' namespace before onboarding the cluster again."
            )
            return
        try:
            api_response = api_instance.list_namespace(
                field_selector="metadata.name=azure-arc"
            )
            if not api_response.items:
                return
            time.sleep(5)
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.exception("Error while retrieving namespace information.")
            kubernetes_exception_handler(
                e,
                consts.Get_Kubernetes_Namespace_Fault_Type,
                "Unable to fetch kubernetes namespace",
                raise_error=False,
            )


def delete_arc_agents(
    release_namespace: str,
    kube_config: str | None,
    kube_context: str | None,
    helm_client_location: str,
    is_arm64_cluster: bool = False,
    no_hooks: bool = False,
    cmd: CLICommand | None = None,
) -> None:
    print(f"Step: {get_utctimestring()}: Uninstalling Arc Agents' Helm release")
    if no_hooks:
        cmd_helm_delete = [
            helm_client_location,
            "delete",
            "azure-arc",
            "--namespace",
            release_namespace,
            "--no-hooks",
        ]
    else:
        cmd_helm_delete = [
            helm_client_location,
            "delete",
            "azure-arc",
            "--namespace",
            release_namespace,
        ]
    if is_arm64_cluster:
        cmd_helm_delete.extend(["--timeout", "15m"])
    if kube_config:
        cmd_helm_delete.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_delete.extend(["--kube-context", kube_context])
    response_helm_delete = Popen(cmd_helm_delete, stdout=PIPE, stderr=PIPE)
    _, error_helm_delete = response_helm_delete.communicate()
    if response_helm_delete.returncode != 0:
        error = process_helm_error_detail(
            error_helm_delete.decode("ascii", errors="replace")
        )
        user_fault = bool(
            "forbidden" in error
            or "Error: warning: Hook pre-delete" in error
            or "Error: timed out waiting for the condition" in error
        )
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_RELEASE_DELETE_FAILED,
            exception=Exception(error),
            user_fault=user_fault,
            details=(
                f"{error} Run 'helm delete azure-arc --namespace "
                f"{release_namespace}' to ensure the release is deleted."
            ),
        )
    ensure_namespace_cleanup()
    # Cleanup azure-arc-release NS if present (created during helm installation)
    cleanup_release_install_namespace_if_exists()


def cleanup_release_install_namespace_if_exists() -> None:
    print(
        f"Step: {get_utctimestring()}: Clean up release namespace '{consts.Release_Install_Namespace}'."
    )
    api_instance = kube_client.CoreV1Api()
    try:
        api_instance.read_namespace(consts.Release_Install_Namespace)
    except ApiException as ex:
        if ex.status == 404:
            # Nothing to delete, exiting here
            return

        kubernetes_exception_handler(
            ex,
            consts.Get_Kubernetes_Helm_Release_Namespace_Fault_Type,
            error_message="Unable to fetch details about existense of kubernetes "
            f"namespace: {consts.Release_Install_Namespace}",
            summary="Unable to fetch kubernetes "
            f"namespace: {consts.Release_Install_Namespace}",
        )

    # If namespace exists, delete it
    try:
        api_instance.delete_namespace(consts.Release_Install_Namespace)
    except ApiException as ex:
        kubernetes_exception_handler(
            ex,
            consts.Delete_Kubernetes_Helm_Release_Namespace_Fault_Type,
            error_message="Unable to clean-up kubernetes "
            f"namespace: {consts.Release_Install_Namespace}",
            summary="Unable to delete kubernetes "
            f"namespace: {consts.Release_Install_Namespace}",
        )


def should_use_secret_injection_flow(
    release_train: str | None, agent_version: str | None
) -> bool:
    """
    Determine whether to use the secure onboarding flow that pre-creates the
    onboarding private key as a Kubernetes Secret (instead of passing it through
    helm values).

    Older agents whose helm chart unconditionally renders the privatekey secret
    from ``global.onboardingPrivateKey`` must keep using the legacy flow,
    otherwise the helm release would re-render the secret with an empty
    ``privateKey`` and leave the cluster stuck in a disconnected state. The
    chart change that gates the privatekey secret on the helm value being set
    ships in:

    * ``stable``  release train: agent version ``1.35.3`` and above.
    * ``preview`` release train: agent version ``1.35.3-preview`` and above.
    * any other release train (e.g. ``dev``): keep the legacy flow for safety.
    * any agent version ending in ``-dev`` (e.g. ``0.2.5738-dev``) is treated
      as a dev build and always uses the secure flow, regardless of the train
      DP attributed it to. This handles the case where a developer overrides
      ``HELMREGISTRY`` to a dev chart while DP still reports the original
      ``stable``/``preview`` train.

    From those versions onward the chart only renders the privatekey secret
    when ``global.onboardingPrivateKey`` is provided, so simply omitting the
    helm value is sufficient to hand secret ownership to the kubectl-injected
    resource.
    """
    # Dev-suffixed agent versions always use the secure flow, regardless of the
    # release train DP attributed them to.
    if agent_version and agent_version.lower().endswith("-dev"):
        return True

    effective_train = (release_train or consts.Stable_Release_Train).lower()
    if effective_train == consts.Stable_Release_Train:
        cutoff = consts.Min_Agent_Version_For_Secret_Injection
    elif effective_train == consts.Preview_Release_Train:
        cutoff = consts.Min_Agent_Version_For_Secret_Injection_Preview
    else:
        # Unknown trains (neither stable nor preview) keep the legacy
        # helm-values flow for safety.
        return False

    if not agent_version:
        # Cannot determine version on a gated train. Be safe and use the legacy
        # flow so that older agents aren't broken.
        return False
    try:
        return version.parse(agent_version) >= version.parse(cutoff)
    except Exception:  # pylint: disable=broad-except
        # If we can't parse the version, fall back to the legacy flow.
        return False


def ensure_arc_namespace_with_helm_metadata() -> None:
    """
    Ensure the ``azure-arc`` namespace exists and is annotated/labeled so that
    the subsequent ``helm install`` can adopt it without erroring out with
    "exists and cannot be imported into the current release".
    """
    api_instance = kube_client.CoreV1Api()
    helm_labels = {"app.kubernetes.io/managed-by": "Helm"}
    helm_annotations = {
        "meta.helm.sh/release-name": consts.Helm_Release_Name,
        "meta.helm.sh/release-namespace": consts.Release_Install_Namespace,
    }

    try:
        existing_ns = api_instance.read_namespace(consts.Arc_Namespace)
    except ApiException as ex:
        if ex.status != 404:
            kubernetes_exception_handler(
                ex,
                consts.Get_Kubernetes_Namespace_Fault_Type,
                error_message=f"Unable to fetch namespace '{consts.Arc_Namespace}'",
                summary=f"Unable to fetch namespace '{consts.Arc_Namespace}'",
            )
            return
        # Namespace does not exist, create it with the required metadata.
        ns_body = kube_client.V1Namespace(
            metadata=kube_client.V1ObjectMeta(
                name=consts.Arc_Namespace,
                labels=helm_labels,
                annotations=helm_annotations,
            )
        )
        try:
            api_instance.create_namespace(ns_body)
        except ApiException as create_ex:
            kubernetes_exception_handler(
                create_ex,
                consts.Inject_PrivateKey_Secret_Fault_Type,
                error_message=f"Unable to create namespace '{consts.Arc_Namespace}'",
                summary=f"Unable to create namespace '{consts.Arc_Namespace}'",
            )
        return

    # Namespace exists; merge in the Helm adoption metadata so helm can manage it.
    metadata = existing_ns.metadata or kube_client.V1ObjectMeta()
    labels = dict(metadata.labels or {})
    annotations = dict(metadata.annotations or {})
    labels.update(helm_labels)
    annotations.update(helm_annotations)
    patch_body = {"metadata": {"labels": labels, "annotations": annotations}}
    try:
        api_instance.patch_namespace(consts.Arc_Namespace, patch_body)
    except ApiException as patch_ex:
        kubernetes_exception_handler(
            patch_ex,
            consts.Inject_PrivateKey_Secret_Fault_Type,
            error_message=(
                f"Unable to patch namespace '{consts.Arc_Namespace}' with Helm "
                "ownership metadata"
            ),
            summary=(
                f"Unable to patch namespace '{consts.Arc_Namespace}' with Helm "
                "ownership metadata"
            ),
        )


def inject_onboarding_private_key_secret(private_key_pem: str) -> None:
    """
    Pre-create the onboarding private key as a Kubernetes Secret so the agents
    can consume it without ever exposing it through helm values. The namespace
    and secret are annotated/labeled for Helm adoption so the chart can manage
    them on subsequent upgrades.

    This MUST be called before ``helm install`` so that the cluster never sits
    in a state where the private key is missing (which would leave it stuck in
    a disconnected state since the Cluster Identity Operator depends on this
    secret to fetch identity certificates from HIS).
    """
    print(
        f"Step: {get_utctimestring()}: Pre-creating onboarding private key "
        f"secret '{consts.Onboarding_PrivateKey_Secret_Name}' in namespace "
        f"'{consts.Arc_Namespace}'."
    )
    ensure_arc_namespace_with_helm_metadata()

    api_instance = kube_client.CoreV1Api()
    secret_body = kube_client.V1Secret(
        metadata=kube_client.V1ObjectMeta(
            name=consts.Onboarding_PrivateKey_Secret_Name,
            namespace=consts.Arc_Namespace,
            labels={"app.kubernetes.io/managed-by": "Helm"},
            annotations={
                "meta.helm.sh/release-name": consts.Helm_Release_Name,
                "meta.helm.sh/release-namespace": consts.Release_Install_Namespace,
            },
        ),
        type="Opaque",
        string_data={consts.Onboarding_PrivateKey_Secret_Data_Key: private_key_pem},
    )

    try:
        api_instance.create_namespaced_secret(consts.Arc_Namespace, secret_body)
    except ApiException as ex:
        if ex.status != 409:
            kubernetes_exception_handler(
                ex,
                consts.Inject_PrivateKey_Secret_Fault_Type,
                error_message=(
                    "Unable to create onboarding private key secret "
                    f"'{consts.Onboarding_PrivateKey_Secret_Name}' in namespace "
                    f"'{consts.Arc_Namespace}'"
                ),
                summary="Unable to create onboarding private key secret",
            )
            return
        # Secret already exists - replace its contents
        # so the cluster always uses a private key matching the public key in ARM
        try:
            api_instance.replace_namespaced_secret(
                consts.Onboarding_PrivateKey_Secret_Name,
                consts.Arc_Namespace,
                secret_body,
            )
        except ApiException as replace_ex:
            kubernetes_exception_handler(
                replace_ex,
                consts.Inject_PrivateKey_Secret_Fault_Type,
                error_message=(
                    "Unable to update existing onboarding private key secret "
                    f"'{consts.Onboarding_PrivateKey_Secret_Name}' in namespace "
                    f"'{consts.Arc_Namespace}'"
                ),
                summary="Unable to update onboarding private key secret",
            )


# DO NOT use this method for re-put scenarios. This method involves new NS creation for helm
# release. For re-put scenarios, brownfield scenario needs to be handled where helm release
# still stays in default NS
# pylint: disable=too-many-locals
# Multiple local variables needed for helm release configuration and installation
def helm_install_release(
    resource_manager: str,
    chart_path: str,
    kubernetes_distro: str,
    kubernetes_infra: str,
    location: str,
    private_key_pem: str,
    kube_config: str | None,
    kube_context: str | None,
    no_wait: bool,
    values_file: str | None,
    cloud_name: str,
    enable_custom_locations: bool,
    custom_locations_oid: str,
    helm_client_location: str,
    enable_private_link: bool | None,
    arm_metadata: dict[str, Any],
    helm_content_values: dict[str, Any],
    registry_path: str,
    aad_identity_principal_id: str | None,
    onboarding_timeout: str = consts.DEFAULT_MAX_ONBOARDING_TIMEOUT_HELMVALUE_SECONDS,
    inject_private_key_via_helm: bool = True,
    cmd: CLICommand | None = None,
) -> None:
    cmd_helm_install = [
        helm_client_location,
        "upgrade",
        "--install",
        "azure-arc",
        chart_path,
        "--set",
        f"global.kubernetesDistro={kubernetes_distro}",
        "--set",
        f"global.kubernetesInfra={kubernetes_infra}",
    ]
    # Pass the onboarding private key through helm values only for older
    # (stable < 1.35.3) agents. Newer agents have already received the key via
    # a pre-created Kubernetes Secret so it never appears in helm values.
    if inject_private_key_via_helm:
        cmd_helm_install.extend(
            ["--set", f"global.onboardingPrivateKey={private_key_pem}"]
        )
    cmd_helm_install.extend(
        [
            "--set",
            "systemDefaultValues.spnOnboarding=false",
            "--set",
            f"global.azureEnvironment={cloud_name}",
            "--set",
            "systemDefaultValues.clusterconnect-agent.enabled=true",
            "--namespace",
            f"{consts.Release_Install_Namespace}",
            "--create-namespace",
            "--output",
            "json",
        ]
    )

    # Special configurations from 2022-09-01 ARM metadata.
    # "dataplaneEndpoints" does not appear in arm_metadata for public and AGC
    if "dataplaneEndpoints" in arm_metadata:
        if "arcConfigEndpoint" in arm_metadata["dataplaneEndpoints"]:
            notification_endpoint = arm_metadata["dataplaneEndpoints"][
                "arcGlobalNotificationServiceEndpoint"
            ]
            config_endpoint = arm_metadata["dataplaneEndpoints"]["arcConfigEndpoint"]
            his_endpoint = arm_metadata["dataplaneEndpoints"][
                "arcHybridIdentityServiceEndpoint"
            ]
            if his_endpoint[-1] != "/":
                his_endpoint = his_endpoint + "/"
            his_endpoint = (
                his_endpoint + f"discovery?location={location}&api-version=1.0-preview"
            )
            relay_endpoint = arm_metadata["suffixes"]["relayEndpointSuffix"]
            active_directory = arm_metadata["authentication"]["loginEndpoint"]
            if not aad_identity_principal_id:
                raise CLIInternalError(
                    "Failed to create the kubeAadEndpoint endpoint. The identity "
                    "principal ID of the created connected cluster is empty."
                )
            kube_aad_endpoint = f"{aad_identity_principal_id}.k8sproxysvc.connectrp.azs"
            cmd_helm_install.extend(
                [
                    "--set",
                    f"global.kubeAadEndpoint={kube_aad_endpoint}",
                    "--set",
                    f"systemDefaultValues.azureResourceManagerEndpoint={resource_manager}",
                    "--set",
                    f"systemDefaultValues.azureArcAgents.config_dp_endpoint_override={config_endpoint}",
                    "--set",
                    f"systemDefaultValues.clusterconnect-agent.notification_dp_endpoint_override={notification_endpoint}",
                    "--set",
                    f"systemDefaultValues.clusterconnect-agent.relay_endpoint_suffix_override={relay_endpoint}",
                    "--set",
                    f"systemDefaultValues.clusteridentityoperator.his_endpoint_override={his_endpoint}",
                    "--set",
                    f"systemDefaultValues.activeDirectoryEndpoint={active_directory}",
                    "--set",
                    "systemDefaultValues.image.repository="
                    f"{registry_path.split('/')[0]}",
                ]
            )
        else:
            logger.debug(
                "'arcConfigEndpoint' doesn't exist under 'dataplaneEndpoints' in the ARM metadata."
            )

    # Add overrides for AGC Scenario
    if cloud_name.lower() == "ussec" or cloud_name.lower() == "usnat":
        add_agc_endpoint_overrides(location, cloud_name, arm_metadata, cmd_helm_install)

    # Add helmValues content response from DP
    cmd_helm_install = parse_helm_values(helm_content_values, cmd_helm=cmd_helm_install)

    # Add custom-locations related params
    if enable_custom_locations and not enable_private_link:
        cmd_helm_install.extend(
            ["--set", "systemDefaultValues.customLocations.enabled=true"]
        )
        cmd_helm_install.extend(
            [
                "--set",
                f"systemDefaultValues.customLocations.oid={custom_locations_oid}",
            ]
        )
    # Disable cluster connect if private link is enabled
    if enable_private_link is True:
        cmd_helm_install.extend(
            ["--set", "systemDefaultValues.clusterconnect-agent.enabled=false"]
        )
    # To set some other helm parameters through file
    if values_file:
        cmd_helm_install.extend(["-f", values_file])
    if kube_config:
        cmd_helm_install.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_install.extend(["--kube-context", kube_context])
    if not no_wait:
        # Change --timeout format for helm client to understand
        onboarding_timeout = onboarding_timeout + "s"
        cmd_helm_install.extend(["--wait", "--timeout", f"{onboarding_timeout}"])
    response_helm_install = Popen(cmd_helm_install, stdout=PIPE, stderr=PIPE)
    _, error_helm_install = response_helm_install.communicate()
    if response_helm_install.returncode != 0:
        helm_install_error_message = error_helm_install.decode(
            "ascii", errors="replace"
        )
        helm_install_error_message = process_helm_error_detail(
            helm_install_error_message
        )
        timeout_report = build_helm_timeout_report(
            helm_install_error_message, helm_operation="install"
        )
        if timeout_report:
            raise report_helm_timeout_error(cmd, timeout_report)
        helm_error_detail = {
            consts.Telemetry_Onboarding_Error_Type_Key: consts.Install_HelmRelease_Fault_Type,
            consts.Telemetry_Onboarding_Error_Message_Key: helm_install_error_message,
        }
        is_user_fault = any(
            message in helm_install_error_message
            for message in consts.Helm_Install_Release_Userfault_Messages
        )
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_RELEASE_OPERATION_FAILED,
            exception=Exception(helm_install_error_message),
            user_fault=is_user_fault,
            telemetry_properties=helm_error_detail,
            operation="install",
            details=helm_install_error_message,
        )


def process_helm_error_detail(helm_error_detail: str) -> str:
    helm_error_detail = remove_rsa_private_key(helm_error_detail)
    helm_error_detail = scrub_proxy_url(helm_error_detail)
    helm_error_detail = redact_base64_strings(helm_error_detail)
    helm_error_detail = redact_sensitive_fields_from_string(helm_error_detail)
    # Remove apostrophes/single quotes to prevent CLI telemetry client parse failures.
    # The telemetry client's _parse_in_json does data.replace("'", '"') which corrupts
    # JSON payloads containing apostrophes (e.g. "Couldn't" becomes invalid JSON).
    helm_error_detail = helm_error_detail.replace("'", "")

    return helm_error_detail


def remove_rsa_private_key(input_text: str) -> str:
    # Regex to identify RSA private key
    rsa_key_pattern = re.compile(
        r"-----BEGIN RSA PRIVATE KEY-----.*?-----END RSA PRIVATE KEY-----", re.DOTALL
    )
    # Search for the key in the input text
    if rsa_key_pattern.search(input_text):
        # Remove the RSA private key
        return rsa_key_pattern.sub("[RSA PRIVATE KEY REMOVED]", input_text)
    return input_text


def scrub_proxy_url(proxy_url_str: str) -> str:
    regex = re.compile(r"://.*?:.*?@")
    # Replace matches with "://[REDACTED]:[REDACTED]@"
    proxy_url_str = regex.sub("://[REDACTED]:[REDACTED]@", proxy_url_str)
    return proxy_url_str


def redact_base64_strings(content: str) -> str:
    base64_pattern = r"\b[A-Za-z0-9+/=]{40,}\b"
    return re.sub(base64_pattern, "[REDACTED]", content)


def redact_sensitive_fields_from_string(input_text: str) -> str:
    # Define regex patterns for keys
    patterns = {
        r"(username:\s*).*": r"\1[REDACTED]",
        r"(password:\s*).*": r"\1[REDACTED]",
        r"(token:\s*).*": r"\1[REDACTED]",
    }

    # Apply regex to redact sensitive fields
    for pattern, replacement in patterns.items():
        input_text = re.sub(pattern, replacement, input_text)

    # Return the redacted text
    return input_text


def get_helm_major_version(helm_client_location: str) -> int:
    """Returns the major version of the helm client (e.g. 3 or 4)."""
    try:
        result = Popen(
            [helm_client_location, "version", "--short"],
            stdout=PIPE,
            stderr=PIPE,
        )
        out, _ = result.communicate()
        version_str = out.decode("ascii").strip()
        # version_str is like "v3.17.0+gabcdef" or "v4.1.3+gabcdef"
        match = re.match(r"v(\d+)\.", version_str)
        if match:
            return int(match.group(1))
    except (OSError, ValueError):
        pass
    return 3  # assume Helm 3 if we cannot determine version


def validate_helm_client(cmd: CLICommand, helm_client_location: str) -> None:
    try:
        response = Popen(
            [helm_client_location, "version", "--short"],
            stdout=PIPE,
            stderr=PIPE,
        )
        output, error = response.communicate()
    except OSError as ex:
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_CLIENT_ERROR,
            exception=ex,
            user_fault=True,
            details=(
                f"Helm client '{helm_client_location}' could not be executed: {ex}"
            ),
        ) from ex

    if response.returncode != 0:
        details = process_helm_error_detail(error.decode("ascii", errors="replace"))
        logger.debug(
            "Unable to validate Helm client %s; continuing so the requested Helm "
            "operation can provide the authoritative failure: %s",
            helm_client_location,
            details,
        )
        return

    version_output = output.decode("ascii", errors="replace").strip()
    major_version_match = re.search(r"v?(\d+)\.", version_output)
    if not major_version_match:
        logger.debug(
            "Unable to determine the Helm major version from %r; continuing so the "
            "requested Helm operation can diagnose compatibility",
            version_output,
        )
        return
    if int(major_version_match.group(1)) < 3:
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_VERSION_TOO_OLD,
            exception=Exception(version_output),
            user_fault=True,
            details=(
                f"Detected Helm version '{version_output}'. Helm version 3 or later "
                "is required."
            ),
        )


def get_release_namespace(
    kube_config: str | None,
    kube_context: str | None,
    helm_client_location: str,
    release_name: str = "azure-arc",
    cmd: CLICommand | None = None,
) -> str | None:
    print(f"Step: {get_utctimestring()}: Get namespace of release: {release_name}")
    cmd_helm_release = [
        helm_client_location,
        "list",
        "--all-namespaces",
        "--output",
        "json",
    ]
    # Helm 4 removed the --all flag (all releases are shown by default).
    # Helm 3 requires --all to include non-deployed releases.
    if get_helm_major_version(helm_client_location) < 4:
        cmd_helm_release.insert(2, "--all")
    if kube_config:
        cmd_helm_release.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_release.extend(["--kube-context", kube_context])
    response_helm_release = Popen(cmd_helm_release, stdout=PIPE, stderr=PIPE)
    output_helm_release, error_helm_release = response_helm_release.communicate()
    if response_helm_release.returncode != 0:
        error = process_helm_error_detail(
            error_helm_release.decode("ascii", errors="replace")
        )
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_RELEASE_LIST_FAILED,
            exception=Exception(error),
            user_fault=(
                "forbidden" in error or "Kubernetes cluster unreachable" in error
            ),
            details=error,
        )

    output_helm_release_str = output_helm_release.decode("ascii", errors="replace")
    try:
        output_helm_release_dict = json.loads(output_helm_release_str)
    except json.decoder.JSONDecodeError:
        return None
    for release in output_helm_release_dict:
        if release["name"] == release_name:
            namespace: str = release["namespace"]
            return namespace
    return None


def flatten(dd: Any, separator: str = ".", prefix: str = "") -> dict[str, Any]:
    try:
        if isinstance(dd, dict):
            return {
                prefix + separator + k if prefix else k: v
                for kk, vv in dd.items()
                for k, v in flatten(vv, separator, kk).items()
            }

        return {prefix: dd}

    except (TypeError, AttributeError, RecursionError) as e:
        telemetry.set_exception(
            exception=e,
            fault_type=consts.Error_Flattening_User_Supplied_Value_Dict,
            summary="Error while flattening the user supplied helm values dict",
        )
        raise CLIInternalError(
            "Error while flattening the user supplied helm values dict"
        ) from e


def check_features_to_update(features_to_update: list[str]) -> tuple[bool, bool, bool]:
    update_cluster_connect, update_azure_rbac, update_cl = False, False, False
    for feature in features_to_update:
        if feature == "cluster-connect":
            update_cluster_connect = True
        elif feature == "azure-rbac":
            update_azure_rbac = True
        elif feature == "custom-locations":
            update_cl = True
    return update_cluster_connect, update_azure_rbac, update_cl


def user_confirmation(message: str, yes: bool = False) -> None:
    if yes:
        return
    try:
        if not prompt_y_n(message):
            raise ManualInterrupt("Operation cancelled.")
    except NoTTYException as exc:
        raise CLIInternalError(
            "Unable to prompt for confirmation as no tty available. Use --yes."
        ) from exc


def is_guid(guid: str) -> bool:
    try:
        uuid.UUID(guid)
        return True
    except ValueError:
        return False


def check_provider_registrations(
    cli_ctx: AzCli,
    subscription_id: str,
    is_gateway_enabled: bool,
    is_workload_identity_enabled: bool,
) -> None:
    print(f"Step: {get_utctimestring()}: Checking Provider Registrations")
    try:
        rp_client = resource_providers_client(cli_ctx, subscription_id)
        cc_registration_state = rp_client.get(
            consts.Connected_Cluster_Provider_Namespace
        ).registration_state
        if cc_registration_state not in consts.allowed_rp_registration_states:
            telemetry.set_exception(
                exception=Exception(
                    f"{consts.Connected_Cluster_Provider_Namespace} provider is not registered"
                ),
                fault_type=consts.CC_Provider_Namespace_Not_Registered_Fault_Type,
                summary=f"{consts.Connected_Cluster_Provider_Namespace} provider is not registered",
            )
            err_msg = (
                f"{consts.Connected_Cluster_Provider_Namespace} provider is not registered. Please register it using 'az provider register -n 'Microsoft."
                "Kubernetes' before running the connect command."
            )
            raise ValidationError(err_msg)
        kc_registration_state = rp_client.get(
            consts.Kubernetes_Configuration_Provider_Namespace
        ).registration_state
        if kc_registration_state not in consts.allowed_rp_registration_states:
            if is_workload_identity_enabled:
                telemetry.set_exception(
                    exception=Exception(
                        f"{consts.Kubernetes_Configuration_Provider_Namespace} provider is not registered"
                    ),
                    fault_type=consts.Kubernetes_Configuration_Provider_Namespace_Not_Registered_Fault_Type,
                    summary=f"{consts.Kubernetes_Configuration_Provider_Namespace} provider is not registered",
                )
                err_msg = (
                    f"{consts.Kubernetes_Configuration_Provider_Namespace} provider is not registered. Please register it using 'az provider register -n 'Microsoft."
                    "KubernetesConfiguration' before running the connect command."
                )
                raise ValidationError(err_msg)

            telemetry.set_user_fault()
            logger.warning(
                "%s provider is not registered",
                consts.Kubernetes_Configuration_Provider_Namespace,
            )
        if is_gateway_enabled:
            hc_registration_state = rp_client.get(
                consts.Hybrid_Compute_Provider_Namespace
            ).registration_state
            if hc_registration_state not in consts.allowed_rp_registration_states:
                telemetry.set_exception(
                    exception=Exception(
                        f"{consts.Hybrid_Compute_Provider_Namespace} provider is not registered"
                    ),
                    fault_type=consts.HC_Provider_Namespace_Not_Registered_Fault_Type,
                    summary=f"{consts.Hybrid_Compute_Provider_Namespace} provider is not registered",
                )
                err_msg = (
                    f"{consts.Hybrid_Compute_Provider_Namespace} provider is not registered. Please register it using 'az provider register -n 'Microsoft."
                    "HybridCompute' before running the connect command."
                )
                raise ValidationError(err_msg)
    except ValidationError:
        raise
    except Exception:  # pylint: disable=broad-exception-caught
        logger.exception("Couldn't check the required provider's registration status")


def can_create_clusterrolebindings() -> bool | str:
    try:
        api_instance = kube_client.AuthorizationV1Api()
        access_review = kube_client.V1SelfSubjectAccessReview(
            spec={
                "resourceAttributes": {
                    "verb": "create",
                    "resource": "clusterrolebindings",
                    "group": "rbac.authorization.k8s.io",
                }
            }
        )
        response = api_instance.create_self_subject_access_review(access_review)
        allowed: bool = response.status.allowed
        return allowed
    except Exception as ex:  # pylint: disable=broad-exception-caught
        warn_msg = (
            "Couldn't check for the permission to create clusterrolebindings on this k8s cluster. "
            f"Error: {ex}"
        )
        logger.warning(warn_msg)
        return "Unknown"


def validate_node_api_response(api_instance: CoreV1Api) -> V1NodeList | None:
    try:
        node_api_response = api_instance.list_node()
        return node_api_response
    except Exception:  # pylint: disable=broad-exception-caught
        logger.debug(
            "Error occcured while listing nodes on this kubernetes cluster:",
            exc_info=True,
        )
        return None


def az_cli(args_str: str) -> Any:
    args = args_str.split()
    cli: AzCli = get_default_cli()
    with open(os.devnull, "w", encoding="utf-8") as devnull:
        cli.invoke(args, out_file=devnull)
    if cli.result.result:
        return cli.result.result
    if cli.result.error:
        raise CLIInternalError(f"'az ${args_str}' failed: {cli.result.error}")
    return True


def is_cli_using_msal_auth() -> bool:
    response_cli_version = az_cli("version --output json")
    try:
        cli_version = response_cli_version["azure-cli"]
    except (KeyError, TypeError) as ex:
        raise CLIInternalError(
            f"Unable to decode the az cli version installed: {ex}"
        ) from ex
    v1 = cli_version
    v2 = consts.AZ_CLI_ADAL_TO_MSAL_MIGRATE_VERSION
    for i, j in zip(map(int, v1.split(".")), map(int, v2.split("."))):
        if i == j:
            continue
        return i > j
    return len(v1.split(".")) == len(v2.split("."))


def get_metadata(arm_endpoint: str, api_version: str = "2022-09-01") -> dict[str, Any]:
    metadata_url_suffix = f"/metadata/endpoints?api-version={api_version}"
    metadata_endpoint = None
    try:
        import requests

        session = requests.Session()
        metadata_endpoint = arm_endpoint + metadata_url_suffix
        response = session.get(metadata_endpoint)
        if response.status_code == 200:
            metadata: dict[str, Any] = response.json()
            return metadata

        msg = f"ARM metadata endpoint '{metadata_endpoint}' returned status code {response.status_code}."
        raise HttpResponseError(msg)

    except Exception as err:  # pylint: disable=broad-exception-caught
        msg = f"Failed to request ARM metadata {metadata_endpoint}."
        print(msg, file=sys.stderr)
        print(
            f"Please ensure you have network connection. Error: {err}",
            file=sys.stderr,
        )
        arm_exception_handler(err, msg, "Failed to get ARM metadata")

    assert False


def parse_helm_values(
    helm_content_values: dict[str, Any], cmd_helm: list[str]
) -> list[str]:
    for helm_param, helm_value in helm_content_values.items():
        if helm_param == "global.proxyCert":
            cmd_helm.extend(["--set-file", f"{helm_param}={helm_value}"])
            continue
        cmd_helm.extend(["--set", f"{helm_param}={helm_value}"])

    return cmd_helm


def get_utctimestring() -> str:
    return time.strftime("%Y-%m-%dT%H-%M-%SZ", time.gmtime())


def helm_update_agent(
    helm_client_location: str,
    kube_config: str | None,
    kube_context: str | None,
    helm_content_values: dict[str, Any],
    values_file: str | None,
    cluster_name: str,
    release_namespace: str,
    chart_path: str,
    cmd: CLICommand | None = None,
) -> None:
    cmd_helm_values = [
        helm_client_location,
        "get",
        "values",
        "azure-arc",
        "--namespace",
        release_namespace,
    ]
    if kube_config:
        cmd_helm_values.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_values.extend(["--kube-context", kube_context])

    user_values_location = os.path.join(
        os.path.expanduser("~"), ".azure", "userValues.txt"
    )
    with open(user_values_location, "w+", encoding="utf-8") as existing_user_values:
        response_helm_values_get = Popen(
            cmd_helm_values, stdout=existing_user_values, stderr=PIPE
        )
        _, error_helm_get_values = response_helm_values_get.communicate()

    if response_helm_values_get.returncode != 0:
        error = process_helm_error_detail(
            error_helm_get_values.decode("ascii", errors="replace")
        )
        if "forbidden" in error or "timed out waiting for the condition" in error:
            raise report_connectedk8s_error(
                cmd,
                errors.HELM_VALUES_GET_FAILED,
                exception=Exception(error),
                user_fault=True,
                details=error,
            )

    cmd_helm_upgrade = [
        helm_client_location,
        "upgrade",
        "azure-arc",
        chart_path,
        "--namespace",
        release_namespace,
        "-f",
        user_values_location,
        "--wait",
        "--output",
        "json",
    ]
    # Add helmValues content response from DP
    cmd_helm_upgrade = parse_helm_values(helm_content_values, cmd_helm=cmd_helm_upgrade)
    if values_file:
        cmd_helm_upgrade.extend(["-f", values_file])
    if kube_config:
        cmd_helm_upgrade.extend(["--kubeconfig", kube_config])
    if kube_context:
        cmd_helm_upgrade.extend(["--kube-context", kube_context])
    response_helm_upgrade = Popen(cmd_helm_upgrade, stdout=PIPE, stderr=PIPE)
    _, error_helm_upgrade = response_helm_upgrade.communicate()
    if response_helm_upgrade.returncode != 0:
        helm_upgrade_error_message = process_helm_error_detail(
            error_helm_upgrade.decode("ascii", errors="replace")
        )
        timeout_report = build_helm_timeout_report(
            helm_upgrade_error_message, helm_operation="update"
        )
        if timeout_report:
            with contextlib.suppress(OSError):
                os.remove(user_values_location)
            raise report_helm_timeout_error(cmd, timeout_report)
        is_user_fault = any(
            message in helm_upgrade_error_message
            for message in consts.Helm_Install_Release_Userfault_Messages
        )
        with contextlib.suppress(OSError):
            os.remove(user_values_location)
        raise report_connectedk8s_error(
            cmd,
            errors.HELM_RELEASE_OPERATION_FAILED,
            exception=Exception(helm_upgrade_error_message),
            user_fault=is_user_fault,
            operation="update",
            details=helm_upgrade_error_message,
        )

    logger.info(str.format(consts.Update_Agent_Success, cluster_name))
    with contextlib.suppress(OSError):
        os.remove(user_values_location)


def add_agc_endpoint_overrides(
    location: str,
    cloud_name: str,
    arm_metadata: dict[str, Any],
    cmd_helm_install: list[str],
) -> None:
    logger.debug("Adding AGC scenario overrides.")

    arm_metadata_endpoint_array = (
        arm_metadata["authentication"]["loginEndpoint"].strip("/").split(".")
    )
    if len(arm_metadata_endpoint_array) < 4:
        raise CLIInternalError("Unexpected loginEndpoint format for AGC")

    cloud_suffix = arm_metadata_endpoint_array[3]
    endpoint_suffix = (
        arm_metadata_endpoint_array[2] + "." + arm_metadata_endpoint_array[3]
    )
    if cloud_name.lower() == "usnat":
        if len(arm_metadata_endpoint_array) < 5:
            raise CLIInternalError("Unexpected loginEndpoint format for AGC")
        cloud_suffix = (
            arm_metadata_endpoint_array[2]
            + "."
            + arm_metadata_endpoint_array[3]
            + "."
            + arm_metadata_endpoint_array[4]
        )
        endpoint_suffix = cloud_suffix

    cmd_helm_install.extend(
        [
            "--set",
            f"global.microsoftArtifactRepository=mcr.microsoft.{cloud_suffix}",
            "--set",
            f"systemDefaultValues.activeDirectoryEndpoint=https://login.microsoftonline.{endpoint_suffix}",
            "--set",
            f"systemDefaultValues.azureArcAgents.config_dp_endpoint_override=https://{location}.dp.kubernetesconfiguration.azure.{endpoint_suffix}",
            "--set",
            f"systemDefaultValues.clusterconnect-agent.connect_dp_endpoint_override=https://{location}.dp.kubernetesconfiguration.azure.{endpoint_suffix}",
            "--set",
            f"systemDefaultValues.clusterconnect-agent.notification_dp_endpoint_override=https://guestnotificationservice.azure.{endpoint_suffix}/",
            "--set",
            f"systemDefaultValues.clusterconnect-agent.relay_endpoint_suffix_override=.servicebus.cloudapi.{endpoint_suffix}",
            "--set",
            f"systemDefaultValues.clusteridentityoperator.his_endpoint_override=https://gbl.his.arc.azure.{endpoint_suffix}/discovery?location={location}&api-version=1.1-preview",
            "--set",
            f"systemDefaultValues.image.repository=mcr.microsoft.{cloud_suffix}",
        ]
    )
