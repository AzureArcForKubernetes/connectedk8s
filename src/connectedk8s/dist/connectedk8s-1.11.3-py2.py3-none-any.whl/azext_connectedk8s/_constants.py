# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------


# pylint: disable=line-too-long

Connected_Cluster_Arm_Id_Telemetry_Context_Key = "connectedk8s_arm_id"
Connected_Cluster_Arm_Id_Telemetry_Property = "Context.Default.AzureCLI.resourceid"
Telemetry_Error_Code_Key = "Context.Default.AzureCLI.errorCode"
Telemetry_Error_Fault_Type_Key = "Context.Default.AzureCLI.errorFaultType"
Telemetry_Error_Name_Key = "Context.Default.AzureCLI.errorName"
Telemetry_Error_Message_Key = "Context.Default.AzureCLI.errorMessage"
Telemetry_Error_Tsg_Link_Key = "Context.Default.AzureCLI.errorTsgLink"
Telemetry_Error_Exception_Type_Key = "Context.Default.AzureCLI.errorExceptionType"
Telemetry_Error_Http_Status_Code_Key = "Context.Default.AzureCLI.errorHttpStatusCode"
Telemetry_Warning_Code_Key = "Context.Default.AzureCLI.warningCode"
Telemetry_Warning_Fault_Type_Key = "Context.Default.AzureCLI.warningFaultType"
Telemetry_Warning_Name_Key = "Context.Default.AzureCLI.warningName"
Telemetry_Warning_Message_Key = "Context.Default.AzureCLI.warningMessage"
Telemetry_Warning_Tsg_Link_Key = "Context.Default.AzureCLI.warningTsgLink"

Distribution_Enum_Values = [
    "generic",
    "openshift",
    "rancher_rke",
    "kind",
    "k3s",
    "minikube",
    "gke",
    "eks",
    "aks",
    "aks_management",
    "aks_workload",
    "capz",
    "aks_engine",
    "tkg",
    "canonical",
    "karbon",
    "aks_edge_k3s",
    "aks_edge_k8s",
]
Public_Cloud_Distribution_List = ["gke", "eks", "aks"]
Infrastructure_Enum_Values = [
    "generic",
    "azure",
    "aws",
    "gcp",
    "azure_stack_hci",
    "azure_stack_hub",
    "azure_stack_edge",
    "vsphere",
    "windows_server",
    "Windows 11 Enterprise",
    "Windows 11 Enterprise N",
    "Windows 11 IoT Enterprise",
    "Windows 11 Pro",
    "Windows 10 Enterprise",
    "Windows 10 Enterprise N",
    "Windows 10 Enterprise LTSC 2021",
    "Windows 10 Enterprise N LTSC 2021",
    "Windows 10 IoT Enterprise",
    "Windows 10 IoT Enterprise LTSC 2021",
    "Windows 10 Pro",
    "Windows 10 Enterprise LTSC 2019",
    "Windows 10 Enterprise N LTSC 2019",
    "Windows 10 IoT Enterprise LTSC 2019",
    "Windows Server 2022",
    "Windows Server 2022 Datacenter",
    "Windows Server 2022 Standard",
    "Windows Server 2019",
    "Windows Server 2019 Datacenter",
    "Windows Server 2019 Standard",
    "Windows 10 IoT Enterprise",
    "LTSCWindows 10 Enterprise LTSC",
]
AHB_Enum_Values = ["True", "False", "NotApplicable"]
Feature_Values = ["cluster-connect", "azure-rbac", "custom-locations"]
CRD_FOR_FORCE_DELETE = [
    "arccertificates.clusterconfig.azure",
    "azureclusteridentityrequests.clusterconfig.azure",
    "azureextensionidentities.clusterconfig.azure",
    "connectedclusters.arc.azure",
    "customlocationsettings.clusterconfig.azure",
    "extensionconfigs.clusterconfig.azure",
    "gitconfigs.clusterconfig.azure",
]
Helm_Install_Release_Userfault_Messages = [
    "forbidden",
    "timed out waiting for the condition",
    "connection refused",
]
Helm_Timeout_Messages = (
    "timed out waiting for the condition",
    "context deadline exceeded",
    "deadline exceeded",
)
Helm_Timeout_Signal_Classifications = (
    "ImagePullFailure",
    "CrashLoopBackOff",
    "ContainerCreateFailure",
    "PendingOrUnschedulable",
    "ClusterResourceOrSchedulingConstraint",
    "MissingIdentityCertificateSecret",
    "MissingKubeAadProxyCertificateSecret",
    "KeyPairOrIdentityCertificateSync",
)
Helm_Timeout_Resolved_Classifications = (
    "GenericHelmTimeout",
    "ImagePullFailure",
    "PendingOrUnschedulable",
    "ClusterIdentityFailure",
)
Max_Helm_Timeout_Diagnostic_Evidence = 8
Max_Helm_Timeout_Event_Evidence = 5
Cluster_Identity_Operator_Prefix = "clusteridentityoperator"
Custom_Locations_Provider_Namespace = "Microsoft.ExtendedLocation"
Connected_Cluster_Provider_Namespace = "Microsoft.Kubernetes"
Kubernetes_Configuration_Provider_Namespace = "Microsoft.KubernetesConfiguration"
Hybrid_Compute_Provider_Namespace = "Microsoft.HybridCompute"
Arc_Namespace = "azure-arc"
Azure_PublicCloudName = "AZUREPUBLICCLOUD"
Azure_USGovCloudName = "AZUREUSGOVERNMENTCLOUD"
Azure_ChinaCloudName = "AZURECHINACLOUD"
Azure_DogfoodCloudName = "AZUREDOGFOOD"
PublicCloud_OriginalName = "AZURECLOUD"
MSI_Certificate_Secret_Name = "azure-identity-certificate"
KAP_Certificate_Secret_Name = "kube-aad-proxy-certificate"
USGovCloud_OriginalName = "AZUREUSGOVERNMENT"
Dogfood_RMEndpoint = "https://api-dogfood.resources.windows-int.net/"
Client_Request_Id_Header = "x-ms-client-request-id"
Correlation_Request_Id_Header = "x-ms-correlation-request-id"
Default_Onboarding_Source_Tracking_Guid = "77ade16b-0f55-403b-b7d2-739554a897f2"
Custom_Access_Token_Env_Var_Sub_Id_Missing_Fault_Type = "Required environment variable SubscriptionId not set, for custom Azure access token"
Custom_Access_Token_Env_Var_Tenant_Id_Missing_Fault_Type = (
    "Required environment variable TenantId not set, for custom Azure access token"
)
Custom_Token_Env_Var_Sub_Id_Missing_Fault_Type = "Required environment variable 'AZURE_SUBSCRIPTION_ID' is not set, when using Custom Acces Token."
Release_Install_Namespace = "azure-arc-release"
Helm_Release_Name = "azure-arc"
Onboarding_PrivateKey_Secret_Name = "azure-arc-connect-privatekey"
Onboarding_PrivateKey_Secret_Data_Key = "privateKey"
Min_Agent_Version_For_Secret_Injection = "1.35.3"
Min_Agent_Version_For_Secret_Injection_Preview = "1.35.3-preview"
Stable_Release_Train = "stable"
Preview_Release_Train = "preview"
Inject_PrivateKey_Secret_Fault_Type = "inject-private-key-secret-error"
Strip_Chart_PrivateKey_Secret_Fault_Type = "strip-chart-private-key-secret-error"
Workload_Identity_Release_Name = "wiextension"
Workload_Identity_Release_Namespace = "arc-workload-identity"
Helm_Environment_File_Fault_Type = "helm-environment-file-error"
Invalid_Location_Fault_Type = "location-validation-error"
Location_Fetch_Fault_Type = "location-fetch-error"
Pls_Location_Mismatch_Fault_Type = "pls-location-mismatch-error"
Pls_Resource_Not_Found = "pls-resource-not-found"
Invalid_Argument_Fault_Type = "argument-validation-error"
Load_Kubeconfig_Fault_Type = "kubeconfig-load-error"
Read_ConfigMap_Fault_Type = "configmap-read-error"
Create_ConfigMap_Fault_Type = "configmap-create-error"
Get_ResourceProvider_Fault_Type = "resource-provider-fetch-error"
Get_ConnectedCluster_Fault_Type = "connected-cluster-fetch-error"
Create_ConnectedCluster_Fault_Type = "connected-cluster-create-error"
Update_ConnectedCluster_Fault_Type = "connected-cluster-update-error"
Delete_ConnectedCluster_Fault_Type = "connected-cluster-delete-error"
Bad_DeleteRequest_Fault_Type = "bad-delete-request-error"
Cluster_Already_Onboarded_Fault_Type = "cluster-already-onboarded-error"
Resource_Already_Exists_Fault_Type = "resource-already-exists-error"
Resource_Does_Not_Exist_Fault_Type = "resource-does-not-exist-error"
Create_ResourceGroup_Fault_Type = "resource-group-creation-error"
Add_HelmRepo_Fault_Type = "helm-repo-add-error"
List_HelmRelease_Fault_Type = "helm-list-release-error"
KeyPair_Generate_Fault_Type = "keypair-generation-error"
PublicKey_Export_Fault_Type = "publickey-export-error"
PrivateKey_Export_Fault_Type = "privatekey-export-error"
Install_HelmRelease_Fault_Type = "helm-release-install-error"
Helm_Timeout_ImagePull_Fault_Type = "helm-timeout-image-pull-failure"
Helm_Timeout_PendingOrUnschedulable_Fault_Type = "helm-timeout-pending-or-unschedulable"
Helm_Timeout_ClusterIdentity_Fault_Type = "helm-timeout-cluster-identity-error"
Helm_Timeout_Generic_Fault_Type = "helm-timeout-error"
Helm_Client_Error_Type = "helm-client-error"
Install_Prediagnostics_Fault_Type = "prediagnostics-failure"
Install_Prediagnostics_Job_Execution_Error_Fault_Type = (
    "prediagnostics-job-execution-error"
)
Post_Diagnostic_Precheck_Fault_Type = "post-diagnostic-precheck-failure"
Telemetry_Onboarding_Error_Type_Key = "Context.Default.AzureCLI.onboardingErrorType"
Telemetry_Onboarding_Error_Message_Key = (
    "Context.Default.AzureCLI.onboardingErrorMessage"
)
Delete_HelmRelease_Fault_Type = "helm-release-delete-error"
Check_PodStatus_Fault_Type = "check-pod-status-error"
Kubernetes_Connectivity_FaultType = "kubernetes-cluster-connection-error"
Helm_Version_Fault_Type = "helm-not-updated-error"
Check_HelmVersion_Fault_Type = "helm-version-check-error"
Helm_Installation_Fault_Type = "helm-not-installed-error"
Check_HelmInstallation_Fault_Type = "check-helm-installed-error"
Get_HelmRegistery_Path_Fault_Type = "helm-registry-path-fetch-error"
Pull_HelmChart_Fault_Type = "helm-chart-pull-error"
Export_HelmChart_Fault_Type = "helm-chart-export-error"
Get_Kubernetes_Distro_Fault_Type = "kubernetes-get-distribution-error"
Get_Kubernetes_Namespace_Fault_Type = "kubernetes-get-namespace-error"
Get_Kubernetes_Helm_Release_Namespace_Fault_Type = (
    "kubernetes-get-helm-release-namespace-error"
)
Delete_Kubernetes_Helm_Release_Namespace_Fault_Type = (
    "kubernetes-delete-helm-release-namespace-error"
)
Update_Agent_Success = "Agents for Connected Cluster {} have been updated successfully"
Update_Agent_Failure = 'Error while updating agents. Please run "kubectl get pods -n azure-arc" to check the pods in case of timeout error. Error: {}'
Agent_State_Succeeded = "Succeeded"
Agent_State_Failed = "Failed"
Agent_State_Timeout = 15
Agent_State_Timeout_Fault_Type = "agent-state-timeout-error"
Provisioned_Cluster_Operation_Fault_Type = "provisioned-cluster-unsupported-operation"
Update_No_Params_Fault_Type = "update-no-parameters-specified"
Update_Proxy_Conflict_Fault_Type = "update-proxy-parameters-conflict"
Connected_Cluster_Resource_Id_None_Fault_Type = (
    "connected-cluster-resource-id-none-error"
)
Custom_Locations_Enable_Failed_Fault_Type = "custom-locations-enable-failed"
Get_Credentials_Failed_Fault_Type = "failed-to-get-list-cluster-user-credentials"
Failed_To_Merge_Credentials_Fault_Type = "failed-to-merge-credentials"
Kubeconfig_Failed_To_Load_Fault_Type = "failed-to-load-kubeconfig-file"
Failed_To_Load_K8s_Configuration_Fault_Type = "failed-to-load-kubernetes-configuration"
Failed_To_Inject_Private_Key_Fault_Type = "failed-to-inject-private-key"
Failed_To_Merge_Kubeconfig_File = "failed-to-merge-kubeconfig-file"
Download_Helm_Fault_Type = "helm-client-download-error"
Create_HelmExe_Fault_Type = "helm-client-create-error"
Extract_HelmExe_Fault_Type = "helm-client-extract-error"
DP_Health_Check_Fault_Type = "dp-health-check-error"
Different_Object_With_Same_Name_Fault_Type = "Kubeconfig has an object with same name"
Download_Exe_Fault_Type = (
    "Error while downloading client proxy executable from storage account"
)
Create_Directory_Fault_Type = (
    "Error while creating directory for placing the executable"
)
Remove_File_Fault_Type = "Error while deleting the specified file"
Run_Clientproxy_Fault_Type = "Error while starting client proxy process."
Post_Hybridconn_Fault_Type = (
    "Error while posting hybrid connection details to proxy process"
)
Post_RefreshToken_Fault_Type = (
    "Error while posting refresh token details to proxy process"
)
Merge_Kubeconfig_Fault_Type = "Error while merging kubeconfig."
Create_CSPExe_Fault_Type = "Error while creating csp executable"
Remove_Config_Fault_Type = "Error while removing old csp config"
Load_Creds_Fault_Type = "Error while loading accessToken.json"
Creds_NotFound_Fault_Type = "Credentials of user not found"
Create_Config_Fault_Type = "Error while creating config file for proxy"
Run_RefreshThread_Fault_Type = "Error while starting refresh thread"
Run_Check_CSP_Thread_Fault_Type = "Error while starting 'check csp thread'."
Proxy_Closed_Externally_Fault_Type = "Proxy closed externally."
Client_Proxy_Port_Fault_Type = "Client proxy port was in use."
Unsupported_Fault_Type = (
    "Error while checking operating system.Unsupported OS detected."
)
Helm_Unsupported_OS_Fault_Type = "helm-client-unsupported-os-error."
Port_Check_Fault_Type = "Error while checking if port is in use."
Proxy_Cert_Path_Does_Not_Exist_Fault_Type = "proxy-cert-path-does-not-exist-error"
Proxy_Cert_Path_Does_Not_Exist_Error = (
    "Proxy cert path {} does not exist. Please check the path provided"
)
Get_Kubernetes_Infra_Fault_Type = "kubernetes-get-infrastructure-error"
No_Param_Error = "No parameters were specified with update command. Please run az connectedk8s update --help to check parameters available for update"
Gateway_ArmId_Is_Invalid = "The provided Gateway ArmID in --gateway-resource-id  {} is invalid. Please provide a valid Gateway ArmID."
EnableProxy_Conflict_Error = "Conflict detected: --disable-proxy can not be set with --https-proxy, --http-proxy, --proxy-skip-range, --proxy-cert and --add-proxy-bypass at the same time. Please run az connectedk8s update --help for more information about the parameters"

# Arc service endpoint host suffixes that are bypassed when Arc bypass is requested.
Arc_Service_Endpoints = [
    ".his.arc.azure.{cloud_based_domain}",
    ".dp.kubernetesconfiguration.azure.{cloud_based_domain}",
    ".guestconfiguration.azure.{cloud_based_domain}",
]

# Keyword accepted by --add-proxy-bypass, which bypasses the proxy for the endpoints above.
Proxy_Bypass_Arc_Keyword = "Arc"
Proxy_Bypass_Arc_Helm_Value = "connectedk8sCli.arcProxyBypass"
Proxy_Bypass_Arc_State_Fault_Type = "proxy-bypass-arc-state-invalid"
Proxy_Bypass_Arc_State_Invalid_Error = (
    "Cannot read the saved Arc proxy bypass information. "
    "This command has not changed the proxy settings."
)
Proxy_Bypass_Arc_State_Mismatch_Error = (
    "The saved Arc proxy bypass information does not match the current proxy skip range. "
    "The proxy settings may have been changed outside this CLI. "
    "This command has not changed the proxy settings."
)
# Announces the Arc bypass, naming the endpoints it covers and the command that clears it.
Proxy_Bypass_Arc_Applied_Message = (
    "Bypassing the proxy for Azure Arc endpoints {endpoints}. Run 'az connectedk8s update "
    "-n <connected-cluster-name> -g <resource-group-name> --clear-proxy-bypass Arc' "
    "to clear the Arc bypass."
)
# Names the carry-over and the endpoints kept, so it is not a surprise.
Proxy_Bypass_Arc_Preserved_Warning = (
    "The enabled Arc bypass for Azure Arc endpoints {endpoints} has been kept. "
    "Run 'az connectedk8s update -n <connected-cluster-name> -g <resource-group-name> "
    "--clear-proxy-bypass Arc' to clear it."
)
Proxy_Bypass_Arc_Overlap_Warning = (
    "The Azure Arc endpoints were passed through --proxy-skip-range in the "
    "current or a previous run and will be preserved when "
    "--clear-proxy-bypass Arc is used."
)
# Confirms the clear, naming the endpoints so removing the bypass reads like applying it.
Proxy_Bypass_Arc_Cleared_Message = (
    "Clearing the Arc bypass for Azure Arc endpoints {endpoints}."
)
# Reports a clear that found nothing, so a no-op is not mistaken for a change.
Proxy_Bypass_Arc_Nothing_To_Clear_Warning = (
    "No saved Arc proxy bypass is recorded; there is nothing to clear."
)
# Reconnecting leaves the agents as they are, so the bypass is refused instead of being applied.
Proxy_Bypass_Arc_Reconnect_Error = (
    "--add-proxy-bypass Arc cannot be applied while reconnecting a cluster that is "
    "already onboarded, because reconnecting leaves the agent configuration as it is."
)
# Names the command that does apply the bypass, so the error says how to get past it.
Proxy_Bypass_Arc_Reconnect_Recommendation = (
    "Run 'az connectedk8s update -n <connected-cluster-name> -g <resource-group-name> "
    "--add-proxy-bypass Arc' to bypass the proxy for the Azure Arc service endpoints."
)
Proxy_Bypass_Arc_Reconnect_Fault_Type = "proxy-bypass-arc-reconnect-error"

# Extension type accepted by --add-proxy-bypass, which makes that agent bypass the proxy.
Proxy_Bypass_ContainerInsights_Extension_Type = "Microsoft.AzureMonitor.Containers"
# Values accepted by --add-proxy-bypass and --clear-proxy-bypass.
Proxy_Bypass_Enum_Values = [
    Proxy_Bypass_Arc_Keyword,
    Proxy_Bypass_ContainerInsights_Extension_Type,
]
# Rendered once for the error that lists what the flags accept.
Proxy_Bypass_Allowed_Values = ", ".join(Proxy_Bypass_Enum_Values)
# Lower-cased lookup, so a keyword is matched however the user typed it.
Proxy_Bypass_Allowed_Keywords = frozenset(
    value.lower() for value in Proxy_Bypass_Enum_Values
)
# Names the command that clears the Container Insights bypass, so each message says how to undo it.
Proxy_Bypass_ContainerInsights_Clear = (
    "Run 'az connectedk8s update -n <connected-cluster-name> -g <resource-group-name> "
    "--clear-proxy-bypass "
    f"{Proxy_Bypass_ContainerInsights_Extension_Type}' to stop bypassing the proxy for "
    "Container Insights."
)

# ConfigMap the Container Insights agent reads; ignore_proxy_settings here drives the proxy bypass.
CI_ConfigMap_Name = "container-azm-ms-agentconfig"
CI_ConfigMap_Namespace = "kube-system"
# Data key holding the ama-logs agent settings that carry the proxy_config section.
CI_ConfigMap_Agent_Settings_Key = "agent-settings"
# Section that scopes ignore_proxy_settings; the setting has no effect in any other section.
CI_ConfigMap_Proxy_Config_Section = "[agent_settings.proxy_config]"
# Setting inside that section which drives the proxy bypass.
CI_ConfigMap_Proxy_Bypass_Setting = "ignore_proxy_settings"
# Setting line written to enable the bypass.
CI_ConfigMap_Proxy_Bypass_Enabled = f'{CI_ConfigMap_Proxy_Bypass_Setting} = "true"'
# Setting line written to withdraw the bypass; the agent then honours the proxy again.
CI_ConfigMap_Proxy_Bypass_Disabled = f'{CI_ConfigMap_Proxy_Bypass_Setting} = "false"'
# Section and setting written together when agent-settings has no proxy_config section yet.
CI_ConfigMap_Proxy_Bypass_Block = (
    f"{CI_ConfigMap_Proxy_Config_Section}\n    {CI_ConfigMap_Proxy_Bypass_Enabled}"
)
# Set when this CLI writes ignore_proxy_settings, so a later run can remove it.
CI_ConfigMap_Proxy_Bypass_Annotation = "connectedk8s.arc.azure.com/proxy-bypass"
# Prefix for the error raised when the bypass cannot be applied or removed.
CI_ConfigMap_Error_Message = (
    f"Unable to configure the '{CI_ConfigMap_Name}' ConfigMap that carries the Container Insights "
    "proxy bypass: "
)
# Guidance for the most likely failure, which is no access to the ConfigMap.
CI_ConfigMap_Unauthorized_Message = (
    f"The user does not have the required privileges to update the '{CI_ConfigMap_Name}' "
    f"ConfigMap in the '{CI_ConfigMap_Namespace}' namespace, which carries the Container "
    f"Insights proxy bypass. Please ensure you have permissions to get, create and update "
    f"ConfigMaps in the '{CI_ConfigMap_Namespace}' namespace."
)
# Carries the wording kubernetes_exception_handler used, so a missing resource still reads the same.
CI_ConfigMap_Not_Found_Message = "The requested kubernetes resource was not found."
# Removal failures stop the command, so the message says why and how to get past it.
CI_ConfigMap_Removal_Error_Message = (
    f"Unable to remove the Container Insights proxy bypass from the '{CI_ConfigMap_Name}' "
    f"ConfigMap in the '{CI_ConfigMap_Namespace}' namespace, so Container Insights may still "
    "be bypassing the proxy. The command stopped here without making any further changes; "
    "run it again once the ConfigMap is reachable: "
)
# Reported when removal fails on a path that carries on, so the setting can still be on the cluster.
CI_ConfigMap_Removal_Failed_Warning = (
    f"Unable to remove the Container Insights proxy bypass from the '{CI_ConfigMap_Name}' "
    f"ConfigMap in the '{CI_ConfigMap_Namespace}' namespace, so Container Insights may continue "
    "to bypass the proxy."
)
# Names the rollback, so undoing the bypass is not mistaken for a requested change.
CI_ConfigMap_Rollback_Warning = (
    "Reverting the Container Insights proxy bypass applied by this command."
)
# Reported when an explicit clear finds no ConfigMap, so a no-op is not mistaken for a change.
CI_ConfigMap_Nothing_To_Clear_Warning = (
    f"No Container Insights proxy bypass was found in the '{CI_ConfigMap_Name}' ConfigMap in the "
    f"'{CI_ConfigMap_Namespace}' namespace; there is nothing to clear."
)
# Reported when an explicit clear finds a setting this CLI did not add, so it is left untouched.
CI_ConfigMap_Not_Managed_Warning = (
    f"The '{CI_ConfigMap_Proxy_Bypass_Setting}' setting in the '{CI_ConfigMap_Name}' ConfigMap in "
    f"the '{CI_ConfigMap_Namespace}' namespace was not added by this CLI, so it has been left "
    "unchanged."
)

Manual_Upgrade_Called_In_Auto_Update_Enabled = (
    "Manual Upgrade was called while in auto_Update enabled mode"
)
Upgrade_Agent_Success = (
    "Agents for Connected Cluster {} have been upgraded successfully"
)
Upgrade_Agent_Failure = (
    'Error while upgrading agents. Please run "kubectl get pods -n azure-arc" to check the pods in case of '
    "timeout error. Error: {}"
)
Release_Namespace_Not_Found = "Error while getting azure-arc releasenamespace"
Get_Helm_Values_Failed = "Error while doing helm get values azure-arc"
Helm_Existing_User_Supplied_Value_Get_Fault = (
    "Error while loading the user supplied helm values"
)
Error_Flattening_User_Supplied_Value_Dict = (
    "Error while flattening the user supplied helm values dict"
)
Upgrade_RG_Cluster_Name_Conflict = (
    "The provided cluster name and rg correspond to different cluster"
)
Corresponding_CC_Resource_Deleted_Fault = (
    "CC resource corresponding to this cluster has been deleted by the customer"
)
Kubernetes_Node_Type_Fetch_Fault_OS = (
    "Error while trying to find a linux node for scheduling pods"
)
Kubernetes_Node_Type_Fetch_Fault_Arch = (
    "Error while trying to find an arm64 node for scheduling pods"
)
Linux_Node_Not_Exists = "Kubernetes cluster doesnt have linux node"
Operate_RG_Cluster_Name_Conflict = (
    "The provided cluster name and rg correspond to different cluster being operated on"
)
Custom_Locations_Registration_Check_Fault_Type = (
    "Error while checking resource provider registration of custom locations."
)
Custom_Locations_OID_Fetch_Fault_Type_CLOid_None = (
    "Error while fetching oid for custom locations. CL_Oid is None"
)
Custom_Locations_OID_Fetch_Fault_Type_Exception = (
    "Exception while fetching oid for custom locations."
)
Successfully_Enabled_Features = (
    "Successsfully enabled features: {} for the Connected Cluster {}"
)
Successfully_Disabled_Features = (
    "Successsfully disabled features: {} for the Connected Cluster {}"
)
Error_enabling_Features = (
    'Error while updating agents for enabling features. Please run "kubectl get pods -n azure-arc" to check the '
    "pods in case of timeout error. Error: {}"
)
Error_disabling_Features = (
    'Error while updating agents for disabling features. Please run "kubectl get pods -n '
    'azure-arc" to check the pods in case of timeout error. Error: {}'
)
Proxy_Kubeconfig_During_Deletion_Fault_Type = (
    "Encountered proxy kubeconfig during deletion."
)
Cannot_Create_ClusterRoleBindings_Fault_Type = (
    "Cannot create cluster role bindings on this Kubernets cluster"
)
CC_Provider_Namespace_Not_Registered_Fault_Type = (
    "Connected Cluster Provider MS.K8 namespace not registered"
)
Kubernetes_Configuration_Provider_Namespace_Not_Registered_Fault_Type = "Kubernetes Configuration Provider MS.KubernetesConfiguration namespace not registered"
HC_Provider_Namespace_Not_Registered_Fault_Type = (
    "Hybrid Compute Provider MS.HybridCompute namespace not registered"
)
Default_Namespace_Does_Not_Exist_Fault_Type = "The default namespace defined in the kubeconfig doesn't exist on the kubernetes cluster."
KAP_1P_Server_App_Scope = "6256c85f-0aad-4d50-b960-e6e9b21efe35/.default"
KAP_1P_Server_AppId = "6256c85f-0aad-4d50-b960-e6e9b21efe35"
Get_PublicKey_Info_Fault_Type = (
    "Error while fetching the PoP publickey information from client proxy"
)
PoP_Public_Key_Expried_Fault_Type = (
    "The PoP public key used to generate the at has expired"
)
Post_AT_To_ClientProxy_Failed_Fault_Type = "Failed to post access token to client proxy"
Kubectl_Get_Events_Failed_Fault_Type = "Error occured while doing kubectl get events"
Kubectl_Get_Secrets_Failed_Fault_Type = "Error occured while doing kubectl get secrets"
Fetch_Kubectl_Get_Secrets_Fault_Type = (
    "Exception occured while doing kubectl get secrets"
)
Helm_Values_Save_Failed_Fault_Type = (
    "Error occured while doing helm get values for azure-arc release"
)
Fetch_Helm_Values_Save_Failed_Fault_Type = (
    "Exception occured while doing helm get values for azure-arc release"
)
Wiextension_Helm_Values_Save_Failed_Fault_Type = (
    "Error occured while doing helm get values for wiextension release"
)
Fetch_Wiextension_Helm_Values_Save_Failed_Fault_Type = (
    "Exception occured while doing helm get values for wiextension release"
)
Metadata_CR_Save_Failed_Fault_Type = "Error occured while fetching metadata CR snapshot"
Fetch_Metadata_CR_Save_Failed_Fault_Type = (
    "Exception occured while fetching metadata CR snapshot"
)
Signingkey_CR_Save_Failed_Fault_Type = (
    "Error occured while fetching signingkey CR snapshot"
)
Fetch_Signingkey_CR_Save_Failed_Fault_Type = (
    "Exception occured while fetching signingkey CR snapshot"
)
KAP_CR_Save_Failed_Fault_Type = "Error occured while fetching KAP CR snapshot"
Fetch_KAP_CR_Save_Failed_Fault_Type = "Exception occured while fetching KAP CR snapshot"
Fetch_Arc_Agent_Logs_Failed_Fault_Type = "Error occured in arc agents logger"
Fetch_Arc_Agents_Events_Logs_Failed_Fault_Type = (
    "Error occured in arc agents events logger"
)
Fetch_Arc_Deployment_Logs_Failed_Fault_Type = "Error occured in deployments logger"
Fetch_Arc_Workload_Identity_Pod_Logs_Failed_Fault_Type = (
    "Error occured in arc agents logger"
)
Fetch_Arc_Workload_Identity_Events_Logs_Failed_Fault_Type = (
    "Error occured in arc agents events logger"
)
Fetch_Arc_Workload_Identity_Deployment_Logs_Failed_Fault_Type = (
    "Error occured in deployments logger"
)
Agent_State_Check_Fault_Type = "Error occured while performing the agent state check"
Agent_Version_Check_Fault_Type = (
    "Error occured while performing the agent version check"
)
Diagnoser_Job_Failed_Fault_Type = "Error while executing Diagnoser Job"
Diagnoser_Container_Check_Failed_Fault_Type = (
    "Error occured while performing the diagnoser container checks"
)
Cluster_DNS_Check_Fault_Type = "Error occured while performing cluster DNS check"
Outbound_Connectivity_Check_Fault_Type = (
    "Error occured while performing outbound connectivity check in the cluster"
)
Outbound_Connectivity_Failed_Fault_Type = (
    "Outbound network connectivity failed in cluster diagnostic checks"
)
DNS_Failed_Fault_Type = "DNS resolution failed in cluster diagnostic checks"
MSI_Cert_Check_Fault_Type = (
    "Error occurred while trying to perform MSI ceritificate presence check"
)
Cluster_Security_Policy_Check_Fault_Type = (
    "Error occured while performing cluster security policy check"
)
KAP_Cert_Check_Fault_Type = (
    "Error occurred while trying to perform KAP ceritificate presence check"
)
MSI_Cert_Expiry_Check_Fault_Type = (
    "Error occured while trying to perform the MSI cert expiry check"
)
Diagnostics_Folder_Creation_Failed_Fault_Type = (
    "Error while trying to create diagnostic logs folder"
)
Describe_Stuck_Agents_Fault_Type = (
    "Error occured while storing the description of non running agents"
)
No_Storage_Space_Available_Fault_Type = "No space left on device"
Connected_Cluster_Resource_Fetch_Fault_Type = (
    "Error occured while fetching the Get output of connected cluster"
)
Diagnoser_Result_Fault_Type = "Error while storing the diagnoser results"
Kubectl_Cluster_Info_Failed_Fault_Type = "Error while doing kubectl cluster-info"
Fetch_Kubectl_Cluster_Info_Fault_Type = "Error occured while fetching cluster-info"
Fetch_Kubectl_Cluster_Info = "kubectl_cluster_info"
Operation_Not_Supported_Fault_Type = (
    "This CLI version does not support this operation for Agents older than v1.14"
)
Failed_To_Change_Telemetry_Push_Interval = (
    "Failed to change the telemetry push interval to 1 hr"
)
Diagnostic_Check_Passed = "Passed"
Diagnostic_Check_Failed = "Failed"
Diagnostic_Check_Incomplete = "Incomplete"
Diagnostic_Check_Starting = "Starting"
Diagnostic_Check_Not_Applicable = "NotApplicable"

# Prediagnostic job execution status values
Job_Status_Not_Started = "NotStarted"
Job_Status_Running = "Running"
Job_Status_Completed = "Completed"
Job_Status_Not_Completed = "NotCompleted"
Job_Status_Not_Scheduled = "NotScheduled"
Job_Status_Cleanup_Failed = "CleanupFailed"
Job_Status_Execution_Failed = "ExecutionFailed"

# Name of the checks and operations
Retrieve_Arc_Agents_Event_Logs = "retrieved_arc_agents_event_logs"
Retrieve_Arc_Agents_Logs = "retrieved_arc_agents_logs"
Retrieve_Deployments_Logs = "retrieved_deployments_logs"
Retrieve_Arc_Workload_Identity_Events_Logs = (
    "retrieved_arc_workload_identity_event_logs"
)
Retrieve_Arc_Workload_Identity_Pod_Logs = "retrieved_arc_workload_identity_pod_logs"
Retrieve_Arc_Workload_Identity_Deployments_Logs = (
    "retrieved_arc_workload_identity_deployments_logs"
)
Fetch_Connected_Cluster_Resource = "fetch_connected_cluster_resource"
Storing_Diagnoser_Results_Logs = "storing_diagnoser_results_logs"
MSI_Cert_Expiry_Check = "msi_cert_expiry_check"
KAP_Security_Policy_Check = "kap_security_policy_check"
KAP_Cert_Check = "kap_cert_check"
Diagnoser_Check = "diagnoser_check"
MSI_Cert_Check = "msi_cert_check"
Agent_Version_Check = "agent_version_check"
Arc_Agent_State_Check = "arc_agent_state_check"
# Diagnoser files name
Arc_Agents_Logs = "arc_agents_logs"
Arc_Deployment_Logs = "arc_deployment_logs"
Arc_Diagnostic_Logs = "arc_diagnostic_logs"
Arc_Workload_Identity_Pod_Logs = "arc_workload_identity_pod_logs"
Arc_Workload_Identity_Deployment_Logs = "arc_workload_identity_deployment_logs"
Pre_Onboarding_Check_Logs = "pre_onboarding_check_logs"
Pre_Onboarding_Helm_Charts_Folder_Name = "PreOnboardingChecksCharts"
Pre_Onboarding_Helm_Charts_Release_Name = "clusterdiagnosticchecks"
Describe_Non_Ready_Arc_Agents = "describe_non_ready_arc_agents"
Agent_State = "agent_state.txt"
Arc_Agents_Events = "arc_agent_events.txt"
Arc_Workload_Identity_Events = "arc_workload_identity_events.txt"
Diagnoser_Results = "diagnoser_output.txt"
Connected_Cluster_Resource = "connected_cluster_resource_snapshot.txt"
DNS_Check = "dns_check.txt"
K8s_Cluster_Info = "k8s_cluster_info.txt"
Outbound_Network_Connectivity_Check = "outbound_network_connectivity_check.txt"
Outbound_Network_Connectivity_Check_for_onboarding = (
    "outbound_network_connectivity_check_for_onboarding.txt"
)
Outbound_Network_Connectivity_Check_for_cluster_connect = (
    "outbound_network_connectivity_check_for_cluster_connect.txt"
)
Events_of_Incomplete_Diagnoser_Job = "diagnoser_failure_events.txt"
Wiextension_Helm_Values = "helm_values_arc_workload_identity.txt"
SigningKey_CR_Snapshot = "signingkey_cr_snapshot.txt"

# Connect Precheck Diagnoser constants
Cluster_Diagnostic_Checks_Job_Registry_Path = (
    "azurearck8s/helmchart/stable/clusterdiagnosticchecks:1.31.2"
)
Cluster_Diagnostic_Checks_Helm_Install_Failed_Fault_Type = (
    "Error while installing cluster diagnostic checks helm release"
)
Cluster_Diagnostic_Checks_Execution_Failed_Fault_Type = (
    "Error occured while executing cluster diagnostic checks"
)
Cluster_Diagnostic_Checks_Release_Cleanup_Failed = (
    "Error occured while cleaning up the cluster diagnostic checks helm release"
)
Cluster_Diagnostic_Checks_Job_Not_Scheduled = (
    "Unable to schedule cluster-diagnostic-checks job"
)
Cluster_Diagnostic_Checks_Job_Not_Complete = (
    "Unable to complete cluster-diagnostic-checks job after scheduling"
)
Pre_Onboarding_Diagnostic_Checks_Execution_Failed = (
    "Exception occured while trying to execute pre-onboarding diagnostic checks"
)
Outbound_Connectivity_Check_Failed = "Outbound network connectivity check failed"
Outbound_Connectivity_Check_Failed_For_Onboarding = (
    "Outbound network connectivity check failed for onboarding"
)
Outbound_Connectivity_Non2xx_Response_Type = "prediagnostics-outbound-non2xx-response"
DNS_Check_Failed = "DNS Resolution failed"
Cluster_Diagnostic_Prechecks_Failed = "Cluster diagnostic prechecks failed"
Cluster_Diagnostic_Prechecks_Incomplete = (
    "Cluster diagnostic prechecks failed to complete"
)
Cluster_Diagnostic_Checks_Pod_Description_Save_Failed = (
    "Failed to save cluster diagnostic checks pod description"
)
Cluster_Diagnostic_Checks_Job_Log_Save_Failed = (
    "Failed to save cluster diagnostic checks job log"
)

Manual_Custom_Location_Oid_Warning = """Important! Custom Location feature enablement can't be validated when using a manually provided OID. If the custom location feature is not enabled, you may encounter an error when creating the custom location.
After creating the custom location, run `az customlocation show` and check that ProvisioningState is Succeeded. If ProvisoningState is Failed, then re-try this command with a  valid custom location OID to enable the feature.
For guidance, refer to: https://aka.ms/enable-customlocation"""

Custom_Location_Enable_Failed_warning = """Important! Custom Location feature wasn't enabled due to insufficient privileges on the Service Principal Name. If the custom location feature is not enabled, you will encounter an error when creating the custom location. Refer to: https://aka.ms/enable-cl-spn"""

KubeApi_Connectivity_Failed_Warning = """Unable to verify connectivity to the Kubernetes cluster.
Please check https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/diagnose-connection-issues"""

Kubeconfig_Load_Failed_Warning = """Unable to load the kubeconfig file.
Please check https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/diagnose-connection-issues#is-kubeconfig-pointing-to-the-right-cluster"""

Cluster_Already_Onboarded_Error = """The kubernetes cluster is already onboarded.
Please check if the Kubeconfig is pointing to the correct cluster using  command: kubectl config current-context."""

# Diagnostic Results Name
Outbound_Connectivity_Check_Result_String = "Outbound Network Connectivity"
Outbound_Connectivity_Check_Failed_For_Cluster_Connect = (
    "Outbound network connectivity check failed for Cluster Connect"
)
DNS_Check_Result_String = "DNS Result:"
Entra_Connectivity_Check_Result_String = (
    "Entra Authentication Endpoint Connectivity Check Result"
)
CRD_Ownership_Check_Failed_String = "Check Failed: CRD"

# Canonical fault-type names used by the standardized AZK8S error catalog.
# Aliases retain the exact string values already emitted by existing call sites.
Catch_All_Fault_Type = "unexpected-connectedk8s-error"
Unsupported_OS_Fault_Type = Unsupported_Fault_Type
Unsupported_Operation_Provisioned_Cluster_Fault_Type = (
    Provisioned_Cluster_Operation_Fault_Type
)
Gateway_ArmId_Is_Invalid_Fault_Type = "invalid-gateway-arm-id"
Linux_Node_Not_Exists_Fault_Type = Linux_Node_Not_Exists
Release_Namespace_Not_Found_Fault_Type = Release_Namespace_Not_Found
Get_Helm_Values_Failed_Fault_Type = Get_Helm_Values_Failed
DNS_NXDomain_Fault_Type = "prediagnostics-dns-nxdomain"
DNS_Timeout_Fault_Type = "prediagnostics-dns-timeout"
DNS_ServFail_Fault_Type = "prediagnostics-dns-servfail"
DNS_No_Servers_Reachable_Fault_Type = "prediagnostics-dns-no-servers-reachable"
DNS_Communications_Error_Fault_Type = "prediagnostics-dns-communications-error"
Outbound_Connectivity_Check_Failed_For_Onboarding_Fault_Type = (
    Outbound_Connectivity_Check_Failed_For_Onboarding
)
Outbound_Connectivity_Check_Failed_For_Cluster_Connect_Fault_Type = (
    Outbound_Connectivity_Check_Failed_For_Cluster_Connect
)
Prediagnostics_Outbound_Non2xx_Response_Fault_Type = (
    Outbound_Connectivity_Non2xx_Response_Type
)
Cluster_Diagnostic_Prechecks_Incomplete_Fault_Type = (
    Cluster_Diagnostic_Prechecks_Incomplete
)
Cluster_Diagnostic_Checks_Job_Not_Scheduled_Fault_Type = (
    Cluster_Diagnostic_Checks_Job_Not_Scheduled
)
Cluster_Diagnostic_Checks_Job_Not_Complete_Fault_Type = (
    Cluster_Diagnostic_Checks_Job_Not_Complete
)
Cluster_Diagnostic_Checks_Job_Log_Save_Failed_Fault_Type = (
    Cluster_Diagnostic_Checks_Job_Log_Save_Failed
)
AZ_CLI_ADAL_TO_MSAL_MIGRATE_VERSION = "2.30.0"
CLIENT_PROXY_VERSION = "1.3.035302"
CLIENT_PROXY_FOLDER = ".clientproxy"
API_SERVER_PORT = 47011
CLIENT_PROXY_PORT = 47010
CLIENTPROXY_CLIENT_ID = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"
API_CALL_RETRIES = 12
DEFAULT_REQUEST_TIMEOUT = 10  # seconds
CSP_REFRESH_TIME = 300

# Default timeout in seconds for Onboarding Helm Install
DEFAULT_MAX_ONBOARDING_TIMEOUT_HELMVALUE_SECONDS = "1200"

# URL constants
CLIENT_PROXY_MCR_TARGET = "azureconnectivity/proxy"
HELM_MCR_URL = "azurearck8s/helm"
HELM_VERSION = "v3.20.1"
Download_And_Install_Kubectl_Fault_Type = "Failed to download and install kubectl"
Azure_Access_Token_Variable = "AZURE_ACCESS_TOKEN"
Provisioned_Cluster_Kind = "provisionedcluster"
Helm_Values_Fetch_isProxyEnabled_Failed_Fault_Type = (
    "Helm Values Fetch isProxyEnabled Failed"
)
Helm_Values_Fetch_isCustomCert_Failed_Fault_Type = (
    "Helm Values Fetch isCustomCert Failed"
)
Helm_Values_Fetch_proxyCert_Failed_Fault_Type = "Helm Values Fetch proxyCert Failed"
Doc_Onboarding_PreRequisites_Url = (
    "'https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/quickstart-"
    "connect-cluster?tabs=azure-cli%2Cazure-cloud#prerequisites'"
)
Doc_Network_Requirements_Url = "https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/network-requirements?tabs=azure-cloud"
Doc_Quick_Start_NW_Requirements_Url = (
    "https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/quickstart-connect-cluster?"
    "tabs=azure-cli#meet-network-requirements"
)
Doc_Quick_Start_Outbound_Proxy_Url = (
    "https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/quickstart-connect-cluster?"
    "tabs=azure-cli#connect-using-an-outbound-proxy-server"
)
Doc_Provisioned_Cluster_Delete_Url = "https://learn.microsoft.com/en-us/cli/azure/aksarc?view=azure-cli-latest#az-aksarc-delete"
Doc_Provisioned_Cluster_Update_Url = "https://learn.microsoft.com/en-us/cli/azure/aksarc?view=azure-cli-latest#az-aksarc-update"
Doc_Provisioned_Cluster_Upgrade_Url = "https://learn.microsoft.com/en-us/cli/azure/aksarc?view=azure-cli-latest#az-aksarc-upgrade"
Doc_Agent_Version_Support_Policy_Url = "https://learn.microsoft.com/en-us/azure/azure-arc/kubernetes/agent-upgrade#version-support-policy"

# Acceptable states for required RP registrations to be in
#
# "Application code shouldn't block the creation of resources for a resource provider that is in the registering state."
# See https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types#register-resource-provider
allowed_rp_registration_states = ["Registering", "Registered"]

GATEWAY_LINK_FAULT_TYPE = "gateway-link-error"
Gateway_Cluster_Resource_Update_Failed_Fault_Type = (
    "Gateway-Cluster-Resource-Update-Failed"
)
GATEWAY_ASSOCIATE_URL = "https://management.azure.com/subscriptions/{subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.Kubernetes/connectedClusters/{cluster_name}/providers/Microsoft.HybridCompute/settings/Default?api-version={api_version}"
